
import java.util.ArrayList;

enum Plano {
    MENSAL, SEMESTRAL, ANUAL;}

class FichaTreino {
    private String tipoTreino;
    public FichaTreino(String tipoTreino) {
        this.tipoTreino = tipoTreino;}
    public String getTipoTreino() {
        return tipoTreino;}

    @Override
    public String toString() {
        return "Ficha de Treino: " + tipoTreino; }
}

class Aluno {
    private String nome;
    private Plano plano;
    private FichaTreino fichaTreino; 
    public Aluno(String nome, Plano plano, String tipoTreino) {
        this.nome = nome;
        this.plano = plano;
        this.fichaTreino = new FichaTreino(tipoTreino);
    }

    public String getNome() {
        return nome;}
    public Plano getPlano() {
        return plano;}
    public FichaTreino getFichaTreino() {
        return fichaTreino; }
    @Override
    public String toString() {
        return "Aluno: " + nome + " | Plano: " + plano + " | " + fichaTreino;}
}

class PersonalTrainer {
    private String nome;
    public PersonalTrainer(String nome) {
        this.nome = nome;}

    public void avaliar(Aluno aluno) {
        System.out.println("O Personal Trainer " + nome + " está avaliando o aluno " + aluno.getNome());}
}

public class Academia {
    private String nomeAcademia;
    private ArrayList<Aluno> listaAlunos; 
    public Academia(String nomeAcademia) {
        this.nomeAcademia = nomeAcademia;
        this.listaAlunos = new ArrayList<>();  }
    public void adicionarAluno(Aluno aluno) {
        listaAlunos.add(aluno);
    }

    public void executarDemonstracao() {
        System.out.println("--- Bem-vindo à " + nomeAcademia.toUpperCase() + " --- \n");

        adicionarAluno(new Aluno("Ana Silva", Plano.ANUAL, "Musculação Hipertrofia"));
        adicionarAluno(new Aluno("Bruno Costa", Plano.MENSAL, "Cardio e Emagrecimento"));
        adicionarAluno(new Aluno("Carla Souza", Plano.SEMESTRAL, "Treino Funcional"));

        PersonalTrainer personal = new PersonalTrainer("Rodrigo");
        
        Aluno primeiroAluno = listaAlunos.get(0);
        personal.avaliar(primeiroAluno);
        System.out.println();
        System.out.println("Lista de Alunos Matriculados:");
        for (Aluno aluno : listaAlunos) {
            System.out.println(aluno);}
        System.out.println("\nQuantidade total de alunos (size): " + listaAlunos.size());}

    public static void main(String[] args) {
        Academia minhaAcademia = new Academia("Academia FitLife Castaldi");
        minhaAcademia.executarDemonstracao();}
}
