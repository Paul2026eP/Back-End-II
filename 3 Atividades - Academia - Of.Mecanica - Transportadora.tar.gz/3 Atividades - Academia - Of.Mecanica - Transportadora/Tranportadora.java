import java.util.ArrayList;

enum StatusPedido {
    PAGO, PENDENTE, ENTREGUE; }

class ItemPedido {
    private String nome;
    public ItemPedido(String nome) {
        this.nome = nome; } }

class Pedido {
    private StatusPedido status;
    private ArrayList<ItemPedido> itens;
    public Pedido() {
        this.status = StatusPedido.PAGO;
        this.itens = new ArrayList<>(); }

    public void adicionarItem(String nomeItem) {
        this.itens.add(new ItemPedido(nomeItem));} }

class Caminhao {
    public void entregar(Pedido pedido) {
        System.out.println("\n Entrega realizada com sucesso. Bipada."); } }

class Transportadora {
    private ArrayList<Caminhao> caminhoes;
    public Transportadora() {
        this.caminhoes = new ArrayList<>();}

    public void adicionarCaminhao(Caminhao caminhao) {
        this.caminhoes.add(caminhao); }}

public class Tranportadora {
    public static void main(String[] args) {
        Transportadora transportadora = new Transportadora();
        Caminhao caminhao = new Caminhao();

        transportadora.adicionarCaminhao(caminhao);
        
        Pedido pedido = new Pedido();
        pedido.adicionarItem("Dobradeira Industrial");
        pedido.adicionarItem("Furadeira Industrial");
        pedido.adicionarItem("Prensa do Maguenito");
        caminhao.entregar(pedido); } }
