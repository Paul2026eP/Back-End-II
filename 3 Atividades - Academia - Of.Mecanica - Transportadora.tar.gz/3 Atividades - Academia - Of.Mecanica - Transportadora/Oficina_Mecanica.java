import java.util.ArrayList;
import java.util.List;

enum StatusOrdem {
    ABERTA, EM_ANDAMENTO, CONCLUIDA, CANCELADA, AGUARDANDO_PEÇAS }

class Veiculo {
    private String placa;
    private String modelo;
    public Veiculo(String placa, String modelo) {
        this.placa = placa;
        this.modelo = modelo; }

    public String getPlaca() { return placa; }
    public String getModelo() { return modelo; } }

class Peca {
    private String nome;
    private double preco;
    protected Peca(String nome, double preco) {
        this.nome = nome;
        this.preco = preco; }

    public String getNome() { return nome; }
    public double getPreco() { return preco; } }

class OrdemServico {
    private int id;
    private StatusOrdem status;
    private List<Peca> pecas; 
    public OrdemServico(int id) {
        this.id = id;
        this.status = StatusOrdem.ABERTA;
        this.pecas = new ArrayList<>(); }

    public void adicionarPeca(String nome, double preco) {
        Peca novaPeca = new Peca(nome, preco);
        this.pecas.add(novaPeca);    }
    public void setStatus(StatusOrdem status) { this.status = status; }
    public StatusOrdem getStatus() { return status; }
    public int getId() { return id; }
    public List<Peca> getPecas() { return pecas; } }

class Mecanico {
    private String nome;
    public Mecanico(String nome) {
        this.nome = nome;   }

    public void executarServico(OrdemServico ordem, Veiculo veiculo) {
        ordem.setStatus(StatusOrdem.EM_ANDAMENTO);
        System.out.println("\n O mecânico " + nome + " está trabalhando no veículo [" + 
                           veiculo.getModelo() + " - Placa: " + veiculo.getPlaca() + 
                           "] na Ordem de Serviço #" + ordem.getId());   }
    public String getNome() { return nome; } }

class Oficina {
    private String nome;
    private List<Mecanico> mecanicos; 

    public Oficina(String nome) {
        this.nome = nome;
        this.mecanicos = new ArrayList<>();}
    public void adicionarMecanico(Mecanico mecanico) {
        this.mecanicos.add(mecanico); }
    public void listarMecanicos() {
        System.out.println("\nMecânicos de Serviço na Oficina " + nome + ":");
        for (Mecanico m : mecanicos) {
            System.out.println("- " + m.getNome()); } } }

public class Oficina_Mecanica {
    public static void main(String[] args) {
        System.out.println("\n--- Teste de Manipulação Textual ---");
        String codigoTexto = "OS-2026_Filtro de Oleo";
        


        String textoFormatado = codigoTexto.replace("_", " -> ");
        System.out.println("Peça Exclusiva: " + textoFormatado + "\n");
        System.out.println("--- Execução do Sistema da Oficina ---");

        Mecanico mec1 = new Mecanico("Carlos Silva *");
        Mecanico mec2 = new Mecanico("Ana Souza - Em intervalo");

        Oficina minhaOficina = new Oficina(" - Mecânica Central");
        minhaOficina.adicionarMecanico(mec1);
        minhaOficina.adicionarMecanico(mec2);
        minhaOficina.listarMecanicos();

        Veiculo carro = new Veiculo("ABC-1234", "Honda Civic");
        OrdemServico os = new OrdemServico(101);
 
        os.adicionarPeca("Pastilha de Freio", 150.0);
        os.adicionarPeca("Disco de Freio", 300.0);

        mec1.executarServico(os, carro);
        
        os.setStatus(StatusOrdem.CONCLUIDA);
        System.out.println("Status final da OS #" + os.getId() + ": " + os.getStatus());
    }
}
