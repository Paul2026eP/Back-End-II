public class Olimpiadas {
    public static void main(String[] args) {
        
        String pais1 = "Estados Unidos";
        int ouro1 = 40;
        int prata1 = 44;
        int bronze1 = 42;
        int ano1 = 2024;
        String sede1 = "Paris";
        boolean top10_1 = true;
        int total1 = ouro1 + prata1 + bronze1;

        String pais2 = "China";
        int ouro2 = 40;
        int prata2 = 27;
        int bronze2 = 24;
        int ano2 = 2024;
        String sede2 = "Paris";
        boolean top10_2 = true;
        int total2 = ouro2 + prata2 + bronze2;

        String pais3 = "Japão";
        int ouro3 = 20;
        int prata3 = 12;
        int bronze3 = 13;
        int ano3 = 2024;
        String sede3 = "Paris";
        boolean top10_3 = true;
        int total3 = ouro3 + prata3 + bronze3;

        String pais4 = "Austrália";
        int ouro4 = 18;
        int prata4 = 19;
        int bronze4 = 16;
        int ano4 = 2024;
        String sede4 = "Paris";
        boolean top10_4 = true;
        int total4 = ouro4 + prata4 + bronze4;

        String pais5 = "França";
        int ouro5 = 16;
        int prata5 = 26;
        int bronze5 = 22;
        int ano5 = 2024;
        String sede5 = "Paris";
        boolean top10_5 = true;
        int total5 = ouro5 + prata5 + bronze5;

        String pais6 = "Brasil";
        int ouro6 = 3;
        int prata6 = 7;
        int bronze6 = 10;
        int ano6 = 2024;
        String sede6 = "Paris";
        boolean top10_6 = false;
        int total6 = ouro6 + prata6 + bronze6;

        
        System.out.println("País          | Ouro | Prata | Bronze | Total | Top 10");
        System.out.println("------------------------------------------------------");
        System.out.println(pais1 + "| "   + ouro1 + "   | " + prata1 + "    | " + bronze1 + "     | " + total1 + "   | " + top10_1);
        System.out.println(pais2 + "         | "  + ouro2 + "   | " + prata2 + "    | " + bronze2 + "     | " + total2 + "    | " + top10_2);
        System.out.println(pais3 + "         | "  + ouro3 + "   | " + prata3 + "    | " + bronze3 + "     | " + total3 + "    | " + top10_3);
        System.out.println(pais4 + "     | "  + ouro4 + "   | " + prata4 + "    | " + bronze4 + "     | " + total4 + "    | " + top10_4);
        System.out.println(pais5 + "        | " + ouro5 + "   | " + prata5 + "    | " + bronze5 + "     | " + total5 + "    | " + top10_5);
        System.out.println(pais6 + "        | "  + ouro6 + "    | " + prata6 + "     | " + bronze6 + "     | " + total6 + "    | " + top10_6);
    }
}

