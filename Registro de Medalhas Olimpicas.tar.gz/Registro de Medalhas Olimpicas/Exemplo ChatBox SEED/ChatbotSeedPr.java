import java.util.Scanner;

public class ChatbotSeedPr {

    public static void main(String[] args) {
        Scanner scanner1 = new Scanner(System.in);
        
        System.out.println("==================================================");
        System.out.println("      CHATBOT - ESCOLA TÉCNICA SEED-PR           ");
        System.out.println("==================================================");
        System.out.println("Olá! Seja bem-vindo ao atendimento automatizado.");
        System.out.println("Como posso te ajudar hoje?");
        System.out.println("--------------------------------------------------");

        boolean continuar = true;

        while (continuar) {
            exibirMenu();
            System.out.print("\nDigite o número da sua opção: ");
            String opcao = scanner1.nextLine().trim();

            switch (opcao) {
                case "1":
                    System.out.println("\n[Bot]: Na rede estadual da SEED-PR, oferecemos cursos como:");
                    System.out.println("- Técnico em Informática");
                    System.out.println("- Técnico em Administração");
                    System.out.println("- Técnico em Agronegócio");
                    System.out.println("- Técnico em Desenvolvimento de Sistemas");
                    System.out.println("Consulte a secretaria do seu colégio para a lista exata da sua região!");
                    break;
                case "2":
                    System.out.println("\n[Bot]: As inscrições para os cursos técnicos da SEED-PR geralmente");
                    System.out.println("ocorrem no final de cada semestre através da plataforma oficial");
                    System.out.println("ou diretamente na secretaria da escola técnica portando seus documentos.");
                    break;
                case "3":
                    System.out.println("\n[Bot]: Os estágios e o aprendizado prático são coordenados pelo");
                    System.out.println("setor de estágios de cada colégio. Empresas parceiras divulgam vagas");
                    System.out.println("diretamente no mural da escola ou pelo sistema institucional.");
                    break;
                case "4":
                    System.out.println("\n[Bot]: Entendido. Redirecionando para um atendente pedagógico...");
                    System.out.println("Por favor, aguarde na linha ou entre em contato pelo telefone local da escola.");
                    break;
                case "5":
                    System.out.println("\n[Bot]: Obrigado por utilizar o nosso sistema. Até logo!");
                    continuar = false;
                    break;
                default:
                    System.out.println("\n[Bot] Opção inválida. Por favor, escolha um número de 1 a 5.");
                    break;
            }
            if (continuar) {
                System.out.println("\n--------------------------------------------------");
                System.out.println("Deseja algo mais?");
            }
        }
        scanner1.close();
    }

    private static void exibirMenu() {
        System.out.println("\n1 - Cursos Técnicos Disponíveis");
        System.out.println("2 - Informações sobre Inscrições e Matrículas");
        System.out.println("3 - Estágios e Parcerias");
        System.out.println("4 - Falar com Atendimento Humano");
        System.out.println("5 - Sair do Chat");
    }
}
