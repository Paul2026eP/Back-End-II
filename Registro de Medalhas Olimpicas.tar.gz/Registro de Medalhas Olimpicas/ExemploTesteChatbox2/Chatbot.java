import java.util.Scanner;

public class Chatbot {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean continuar = true;

        System.out.println("==================================================");
        System.out.println("🤖 Bem-vindo ao Chatbot da Escola Técnica SEED-PR!");
        System.out.println("==================================================");

        while (continuar) {
            System.out.println("\nComo posso ajudar você hoje? Selecione uma opção:");
            System.out.println("1️⃣ - Cursos Técnicos Disponíveis");
            System.out.println("2️⃣ - Inscrições e Matrículas");
            System.out.println("3️⃣ - Informações sobre Estágios");
            System.out.println("4️⃣ - Falar com Atendimento Humano");
            System.out.println("5️⃣ - Encerrar Atendimento");
            System.out.print("\nDigite o número da opção: ");

            // Captura como String para evitar bugs com a tecla Enter
            String entrada = scanner.nextLine().trim(); 

            System.out.println("\n--------------------------------------------------");
            switch (entrada) {
                case "1":
                    System.out.println("🤖 Cursos SEED-PR: Oferecemos Desenvolvimento de Sistemas,\n" +
                                       "Administração, Agronegócio, Enfermagem, entre outros.\n" +
                                       "As modalidades mudam conforme a sua cidade!");
                    break;
                case "2":
                    System.out.println("🤖 Matrículas: O período de inscrições geralmente ocorre via\n" +
                                       "Portal da SEED-PR ou diretamente na secretaria da escola técnica\n" +
                                       "com RG, CPF e Histórico Escolar.");
                    break;
                case "3":
                    System.out.println("🤖 Estágios: Alunos técnicos têm acesso ao mural de vagas parceiras.\n" +
                                       "A validação do estágio obrigatório deve ser feita com o coordenador do curso.");
                    break;
                case "4":
                    System.out.println("🤖 Transferindo... Por favor, aguarde na linha para que um\n" +
                                       "secretário escolar dê continuidade ao seu atendimento.");
                    continuar = false;
                    break;
                case "5":
                    System.out.println("🤖 Atendimento encerrado. A SEED-PR agradece o seu contato. Até logo!");
                    continuar = false;
                    break;
                default:
                    System.out.println("⚠️ Opção inválida! Por favor, digite apenas o número de 1 a 5.");
                    break;
            }
            System.out.println("--------------------------------------------------");
        }

        scanner.close();
    }
}
