public class Pessoa {
    private String nome;
    private int idade;

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }
}

public class ContaSemProtecao {
    public double saldo;

    public static void main(String[] args) {
        ContaSemProtecao conta = new ContaSemProtecao();
        conta.saldo = 1000.0;
        System.out.println(conta.saldo);
    }
}
