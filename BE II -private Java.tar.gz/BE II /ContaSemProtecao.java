public class ContaSemProtecao {
    public double saldo;

    public static void main(String[] args) {
        ContaSemProtecao conta = new ContaSemProtecao();
        conta.saldo = -5000.0; //compila
        conta.saldo += 1000.0; //regra ignorada
        System.out.println(conta.saldo);
    }
}
