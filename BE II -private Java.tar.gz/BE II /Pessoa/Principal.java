class Pessoa {
    private String nome;
    private int idade;

    public Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade; 
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }
}

class Conta {
    public double saldo;
    public Pessoa titular; 
}

public class Principal {
    public static void main(String[] args) {
       
        Pessoa cliente = new Pessoa("João", 30);

       
        Conta conta = new Conta();
        conta.saldo = 1000.0;
        conta.titular = cliente;

   
        System.out.println("Titular da conta: " + conta.titular.getNome());
        System.out.println("Saldo da conta: R$ " + conta.saldo);
    }
}
