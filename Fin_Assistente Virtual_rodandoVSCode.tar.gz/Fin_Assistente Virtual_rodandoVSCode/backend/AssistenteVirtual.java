package backend;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class AssistenteVirtual {

    // Mantendo suas variáveis globais e estados do sistema
    private static double saldoGeral = 15250.00;
    private static List<String> tarefasAdmin = new ArrayList<>();
    private static List<String> historicoTransacoes = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        // Inicializa os dados padrões do seu sistema corporativo
        tarefasAdmin.add("Revisar contratos de fornecedores - Prazo: 10/10");
        tarefasAdmin.add("Aprovar folhas de pagamento do setor comercial");
        historicoTransacoes.add("Recebimento Cliente A: +R$ 5.000,00");
        historicoTransacoes.add("Pagamento Luz/Internet: -R$ 450,00");

        // Cria o servidor HTTP focado em escutar a porta 5173 local
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 5173), 0);
        server.createContext("/chat", new ChatHandler());
        server.setExecutor(null); 
        
        System.out.println("====================================================");
        System.out.println("🤖 Servidor do Assistente Empresarial ativo!");
        System.out.println("Rodando em: http://127.0.0");
        System.out.println("====================================================");
        server.start();
    }

    static class ChatHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            // Configurações CORS obrigatórias para o navegador do Linux aceitar o envio
            exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
            exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, OPTIONS");
            exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(204, -1);
                return;
            }

            String query = exchange.getRequestURI().getQuery();
            String mensagemUsuario = "";
            
            if (query != null && query.startsWith("mensagem=")) {
                String apenasTexto = query.substring(9); 
                mensagemUsuario = URLDecoder.decode(apenasTexto, StandardCharsets.UTF_8.toString()).trim().toLowerCase();
            }

            // Processa a resposta baseada nos módulos digitados pelo usuário
            String respostaBot = processarComandoWeb(mensagemUsuario);

            byte[] responseBytes = respostaBot.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", "text/plain; charset=UTF-8");
            exchange.sendResponseHeaders(200, responseBytes.length);
            OutputStream os = exchange.getResponseBody();
            os.write(responseBytes);
            os.close();
        }
    }

    /**
     * Motor de respostas inteligentes que substitui o switch-case do terminal
     * adaptando seu sistema para responder no chat do navegador.
     */
    private static String processarComandoWeb(String mensagem) {
        if (mensagem.isEmpty()) {
            return "Por favor, digite alguma instrução operacional.";
        }

        // Módulo de Atendimento Geral
        if (mensagem.contains("ola") || mensagem.contains("oi") || mensagem.contains("bom dia")) {
            return "Olá! Sou seu assistente corporativo focado em Finanças & Admin. Como posso te ajudar hoje?";
        }

        // Módulo Financeiro
        if (mensagem.contains("saldo")) {
            return String.format("💰 [MÓDULO FINANCEIRO]\nSaldo Geral Consolidado da empresa: R$ %.2f", saldoGeral);
        }
        
        if (mensagem.contains("historico") || mensagem.contains("extrato") || mensagem.contains("transacoes")) {
            StringBuilder sb = new StringBuilder("📋 [MÓDULO FINANCEIRO] Extrato Recente:\n");
            for (String t : historicoTransacoes) {
                sb.append(" • ").append(t).append("\n");
            }
            return sb.toString();
        }

        // Módulo Administrativo
        if (mensagem.contains("tarefa") || mensagem.contains("pendencias") || mensagem.contains("agenda")) {
            if (tarefasAdmin.isEmpty()) {
                return "📌 [MÓDULO ADMINISTRATIVO]\nNenhuma tarefa pendente na agenda da equipe no momento.";
            }
            StringBuilder sb = new StringBuilder("📌 [MÓDULO ADMINISTRATIVO] Tarefas Pendentes:\n");
            for (int i = 0; i < tarefasAdmin.size(); i++) {
                sb.append(String.format(" %d. %s\n", (i + 1), tarefasAdmin.get(i)));
            }
            return sb.toString();
        }

        // Resumo Executivo Geral
        if (mensagem.contains("resumo") || mensagem.contains("insights") || mensagem.contains("status")) {
            String alerta = (saldoGeral < 5000) 
                ? "⚠️ Alerta: O saldo corporativo está abaixo do limite prudencial!" 
                : "🟢 Status: Operação financeira e administrativa estável.";
                
            return String.format("📊 [RESUMO EXECUTIVO DO DIA]\n• Saúde Financeira: Saldo em R$ %.2f\n• Administrativo: %d tarefa(s) pendente(s) hoje.\n\n%s", 
                    saldoGeral, tarefasAdmin.size(), alerta);
        }

        // Resposta Padrão
        return "Desculpe, comando operacional não reconhecido. Você pode perguntar sobre o 'saldo', ver o 'extrato', checar as 'tarefas' ou pedir o 'resumo executive'.";
    }
}
