import java.util.ArrayList;

public class ForEach {
    public static void main(String[] args) {
        ArrayList<String> frutas = new ArrayList<>();
        frutas.add("Maçã");
        frutas.add("Banana");
        frutas.add("Uva");
        frutas.add("Morango");
        frutas.add("Laranja");
        frutas.add("Pera");

        for (String fruta : frutas) {
            System.out.println("Gosto de " + fruta);  }}
                     }