import java.util.Scanner;

public class Frutas {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("Frutas disponíveis:");
        System.out.println("- Maçã");
        System.out.println("- Banana");
        System.out.println("- Uva");
        System.out.println("- Morango");
        System.out.println("- Laranja");
        System.out.println("- Pera");
        System.out.println();

        System.out.print("Que fruta você gosta? ");
        String fruta = teclado.nextLine().toLowerCase();

        System.out.println();

        switch (fruta) {

            case "maçã":
            case "maca":
                System.out.println("MAÇÃ");
                System.out.println("Composição: fibras, vitamina C, água e antioxidantes.");
                System.out.println("Benefícios: auxilia a digestão e ajuda no controle do colesterol.");
                break;

            case "banana":
                System.out.println("BANANA");
                System.out.println("Composição: potássio, magnésio, vitamina B6 e carboidratos.");
                System.out.println("Benefícios: fornece energia e ajuda a prevenir cãibras.");
                break;

            case "uva":
                System.out.println("UVA");
                System.out.println("Composição: flavonoides, resveratrol, vitaminas C e K.");
                System.out.println("Benefícios: possui ação antioxidante.");
                break;

            case "morango":
                System.out.println("MORANGO");
                System.out.println("Composição: vitamina C, flavonoides, fibras e antioxidantes.");
                System.out.println("Benefícios: auxilia a imunidade e a saúde da pele.");
                break;

            case "laranja":
                System.out.println("LARANJA");
                System.out.println("Composição: vitamina C, fibras e ácido cítrico.");
                System.out.println("Benefícios: fortalece o sistema imunológico.");
                break;

            case "pera":
                System.out.println("PERA");
                System.out.println("Composição: fibras, vitamina C e potássio.");
                System.out.println("Benefícios: auxilia o funcionamento intestinal.");
                break;

            default:
                System.out.println("Fruta não cadastrada.");
        }

        teclado.close();
    }
}