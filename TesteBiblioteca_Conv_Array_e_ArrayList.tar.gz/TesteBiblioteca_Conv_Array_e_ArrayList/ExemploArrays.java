import java.util.ArrayList;

public class ExemploArrays {
    public static void main(String[] args) {
        
        // ==========================================
        // 1. EXEMPLO DE ARRAY (Tamanho Fixo)
        // ==========================================
        System.out.println("--- Exemplo de Array ---");
        
        // Inicializando um array de Strings com tamanho fixo de 3 elementos
        String[] nomesArray = new String[3];
        nomesArray[0] = "Ana";
        nomesArray[1] = "Bruno";
        nomesArray[2] = "Carlos";

        // Iterando (percorrendo) o Array
        for (String nome : nomesArray) {
            System.out.println("Nome no Array: " + nome);
        }


        // ==========================================
        // 2. EXEMPLO DE ARRAYLIST (Tamanho Dinâmico)
        // ==========================================
        System.out.println("\n--- Exemplo de ArrayList ---");
        
        // Inicializando um ArrayList de Strings (tamanho cresce automaticamente)
        ArrayList<String> nomesList = new ArrayList<>();
        
        // Adicionando elementos
        nomesList.add("Diana");
        nomesList.add("Eduardo");
        nomesList.add("Flávia");

        // Removendo um elemento (opcional)
        nomesList.remove("Eduardo");

        // Iterando (percorrendo) o ArrayList
        for (String nome : nomesList) {
            System.out.println("Nome no ArrayList: " + nome);
        }
        
        // Buscando um elemento pelo índice no ArrayList
        System.out.println("Primeiro da lista: " + nomesList.get(0));
    }
}
