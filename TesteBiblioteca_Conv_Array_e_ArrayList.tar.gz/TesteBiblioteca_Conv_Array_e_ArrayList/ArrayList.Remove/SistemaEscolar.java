import java.util.ArrayList;
import java.util.List;

public class SistemaEscolar {
    String nome;
    String status; // "Ativo", "Inadimplente", "Formado", "Trancando e Inspirado retorno"

    SistemaEscolar(String nome, String status) {
        this.nome = nome;
        this.status = status;
    }

    @Override
    public String toString() {
        return nome + " - Status: " + status;
    }

    public static void main(String[] args) {
        List<SistemaEscolar> alunos = new ArrayList<>();
        
        // Cadastro dos alunos
        alunos.add(new SistemaEscolar("Ana", "Ativo"));
        alunos.add(new SistemaEscolar("Bruno", "Inadimplente"));
        alunos.add(new SistemaEscolar("Carla", "Formado"));
        alunos.add(new SistemaEscolar("Juliana", "Trancando e Inspirado retorno"));

        // Aluno que o sistema deseja excluir (Alterado para "Juliana")
        String alunoParaExcluir = "Juliana";
        SistemaEscolar alvo = null;

        // Busca o aluno na lista de forma dinâmica
        for (SistemaEscolar a : alunos) {
            if (a.nome.equalsIgnoreCase(alunoParaExcluir)) {
                alvo = a;
                break;
            }
        }

        // Regra de negócio para exclusão usando if, else if, else
        if (alvo == null) {
            System.out.println("Erro: Aluno não encontrado no sistema.");
        } else if (alvo.status.equals("Inadimplente")) {
            System.out.println("Não é possível excluir " + alvo.nome + " pois existem pendências financeiras.");
        } else if (alvo.status.equals("Trancando e Inspirado retorno")) {
            alunos.remove(alvo);
            System.out.println("Aluno(a) " + alvo.nome + " excluída por trancamento e inspiração de retorno.");
        } else {
            alunos.remove(alvo);
            System.out.println("Aluno " + alvo.nome + " excluído com sucesso.");
        }

        // Exibe a lista final
        System.out.println("\nLista de Alunos Atualizada:");
        for (SistemaEscolar a : alunos) {
            System.out.println(a);
        }
    }
}
