import java.util.ArrayList;
import java.util.List;

public class Pessoa4 {
     String nome;
    int idade;
    
    Pessoa4(String nome, int idade) { 
        this.nome = nome;
        this.idade = idade; }

    @Override 
    public String toString() { 
        return nome + " (" + idade + " anos)";  }

    public static void main(String[] args) { 
        List<Pessoa4> pessoas = new ArrayList<>();

        pessoas.add(new Pessoa4("Ana", 25));
        pessoas.add(new Pessoa4("Bruno", 30));
        pessoas.add(new Pessoa4("Carla", 22));
        pessoas.add(new Pessoa4("Diego", 28));//sem limite fixo

        pessoas.remove(1);  //remove "Bruno"
        pessoas.remove(2);  //remove "Diego"
        Pessoa4 primeira = pessoas.get(0); //acessa por indice
        pessoas.set(0, new Pessoa4("Ana Maria", 26)); //substitui

        System.out.println("Tamanho: " + pessoas.size());
        System.out.println("Primeira armazenada antes da troca: " + primeira);
        System.out.println("\nLista de pessoas restante:");
        for (Pessoa4 p : pessoas) {
            System.out.println(p);}
    }
}
