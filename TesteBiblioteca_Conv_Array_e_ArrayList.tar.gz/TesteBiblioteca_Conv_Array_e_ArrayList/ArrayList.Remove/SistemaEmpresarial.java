import java.util.ArrayList;
import java.util.List;

public class SistemaEmpresarial {
    String nome;
    String tipo; // "Comum" ou "VIP"

    SistemaEmpresarial(String nome, String tipo) {
        this.nome = nome;
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return nome + " (Cliente " + tipo + ")";
    }

    public static void main(String[] args) {
        List<SistemaEmpresarial> clientes = new ArrayList<>();
        clientes.add(new SistemaEmpresarial("Empresa Alfa", "Comum"));
        clientes.add(new SistemaEmpresarial("Empresa Beta", "VIP"));
        clientes.add(new SistemaEmpresarial("Empresa Gama", "Comum"));
        clientes.add(new SistemaEmpresarial("Empresa Delta", "Classe_A"));//1. Alfa (Α Beta (Β / β)Gama (Γ / γ)Delta (Δ / δ)Épsilon (Ε / ε) Zeta (Ζ / ζ)Eta (Η / η)Teta ou Theta (Θ / θ)Iota (Ι / ι) Capa ou Kappa (Κ / κ)

        String clienteParaExcluir = "Empresa Beta";
        String nivelUsuarioSistema = "Atendente"; // Pode ser "Admin" ou "Atendente"
        
        SistemaEmpresarial alvo = null;

        for (SistemaEmpresarial c : clientes) {
            if (c.nome.equalsIgnoreCase(clienteParaExcluir)) {
                alvo = c;
                break;
            }
        }

        // Validação de exclusão empresarial
        if (alvo == null) {
            System.out.println("Cliente não localizado.");
        } else if (alvo.tipo.equals("VIP") && !nivelUsuarioSistema.equals("Admin")) {
            System.out.println("Acesso negado: Apenas administradores podem excluir clientes VIP.");
        } else {
            clientes.remove(alvo);
            System.out.println("Cliente " + alvo.nome + " removido da base corporativa.");
        }
    }
}

