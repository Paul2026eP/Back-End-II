import java.util.ArrayList;
import java.util.List;

class Livro {      //auxiliar no mesmo arquivo
    private String titulo;
    public Livro(String titulo) {this.titulo = titulo; }
    public String getTitulo() {return titulo; }
}

public class TesteBiblioteca {
    public static void main(String[] args) {

/* FORMA CONVENCIONAL MANUAL ***
        Livro[] acervo = new Livro[17];       //vetor de 17 referencias
        acervo[0] = new Livro("Dom Casmurro");
        acervo[1] = new Livro("Memórias Póstumas");
        acervo[2] = new Livro("Quincas Borba");
        acervo[3] = new Livro("Torto Arado");
        acervo[4] = new Livro("Os Lusiadas");
        acervo[5] = new Livro("Otelo");
        acervo[6] = new Livro("Sermões");
        acervo[7] = new Livro("O Caçador de Pipas");
        acervo[8] = new Livro("O Cortiço");
        acervo[9] = new Livro("Vidas Secas");
        acervo[10] = new Livro("O Caçador de Pipas");
        acervo[11] = new Livro("Macunaíma");
        acervo[12] = new Livro("Niketche");
        acervo[13] = new Livro("O Ateneu");
        acervo[14] = new Livro("Iracema");
        acervo[15] = new Livro("O Auto da Compadecida");
        acervo[16] = new Livro("Triste Fim de Policarpo Quaresma");

        
        for (int i = 0 /*pode iniciar até 16*//* ; i < acervo.length; i++) {
        System.out.println(acervo[i].getTitulo());
        }
    }
}  
*/


  /* FORMA USANDO ARRAYS ***    
        String[] acervo = {
            "Dom Casmurro", "Memórias Póstumas", "Quincas Borba", "Torto Arado", 
            "Os Lusiadas", "Otelo", "Sermões", "O Caçador de Pipas", "O Cortiço", 
            "Vidas Secas", "O Caçador de Pipas", "Macunaíma", "Niketche", 
            "O Ateneu", "Iracema", "O Auto da Compadecida", "Triste Fim de Policarpo Quaresma"
        };
    }
}*/

//FORMA USANDO ARRAYLIST ***
        // ARRAYLIST DE STRINGS: forma compacta e  dinâmico
        ArrayList<String> acervo = new ArrayList<>(List.of(
            "Dom Casmurro", "Memórias Póstumas", "Quincas Borba", "Torto Arado", 
            "Os Lusiadas", "Otelo", "Sermões", "O Caçador de Pipas", "O Cortiço", 
            "Vidas Secas", "O Caçador de Pipas", "Macunaíma", "Niketche", 
            "O Ateneu", "Iracema", "O Auto da Compadecida", "Triste Fim de Policarpo Quaresma"
        ));


        // O laço for-each funciona exatamente igual para o ArrayList
        for (String livro : acervo) {
            System.out.println(livro);
        }
    }
}

