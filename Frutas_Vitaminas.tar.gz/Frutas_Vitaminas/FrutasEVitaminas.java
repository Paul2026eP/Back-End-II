import java.util.Scanner;

public class FrutasEVitaminas {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        String continuar;

        do {
            System.out.println("\n=== PASSO 1: NUTRIÇÃO UNITÁRIA ===");
            System.out.println("Ingredientes disponíveis:");
            System.out.println("- Maçã               - Banana             - Uva");
            System.out.println("- Morango            - Laranja            - Pera");
            System.out.println("- Abacate            - Aveia              - Mel");
            System.out.println("- Amendoim           - Castanha           - Castanha do Pará");
            System.out.println("- Semente de Abóbora - Sementes           - Kiwi");
            System.out.println();

            System.out.print("Qual ingrediente você quer consultar a nutrição? ");
            String item = teclado.nextLine().toLowerCase().trim();
            System.out.println();

            exibirNutricaoIngrediente(item);

            System.out.println("\n--------------------------------------------------\n");

            System.out.println("=== PASSO 2: SUGESTÕES POR PERFIL NUTRICIONAL ===");
            System.out.println("Perfis disponíveis: Energia | Imunidade | Digestao");
            System.out.print("Qual é o seu perfil nutricional? ");
            String perfil = teclado.nextLine().toLowerCase().trim();
            System.out.println();

            switch (perfil) {
                case "energia":
                    System.out.println("PERFIL ENERGIA - 3 Sugestões:");
                    System.out.println("1. Banana + Aveia + Leite + Amendoim");
                    System.out.println("2. Abacate + Mel + Leite + Castanha do Pará");
                    System.out.println("3. Uva + Banana + Água de coco + Semente de Abóbora");
                    break;

                case "imunidade":
                    System.out.println("PERFIL IMUNIDADE - 3 Sugestões:");
                    System.out.println("1. Morango + Mel + Suco de Laranja + Castanha do Pará");
                    System.out.println("2. Kiwi + Morango + Iogurte + Semente de Abóbora");
                    System.out.println("3. Laranja + Maçã + Água + Castanha");
                    break;

                case "digestao":
                case "digestão":
                    System.out.println("PERFIL DIGESTÃO - 3 Sugestões:");
                    System.out.println("1. Pera + Maçã + Água + Sementes");
                    System.out.println("2. Abacate + Aveia + Leite vegetal + Semente de Abóbora");
                    System.out.println("3. Pera + Banana + Água + Castanha");
                    break;

                default:
                    System.out.println("Perfil não cadastrado.");
            }

            System.out.println("\n--------------------------------------------------\n");

            System.out.println("=== PASSO 3: MONTE A SUA VITAMINA ===");
            System.out.print("1º item - Escolha a 1ª fruta ou base: ");
            String item1 = teclado.nextLine().trim();

            System.out.print("2º item - Escolha a 2ª fruta ou complemento: ");
            String item2 = teclado.nextLine().trim();

            System.out.print("3º item - Escolha a base líquida (ex: Leite, Água, Água de Coco, Suco de Laranja): ");
            String liquido = teclado.nextLine().trim();

            System.out.print(
                    "4º item - Escolha as sementes ou oleaginosas (ex: Amendoim, Castanha, Semente de Abóbora): ");
            String item4 = teclado.nextLine().trim();

            System.out.print("5º item - Como deseja adoçar? (ex: Mel, Açúcar, Açúcar Mascavo, Adoçante, Sem nada): ");
            String adocante = teclado.nextLine().trim();

            System.out.println();
            System.out.println("==================================================");
            System.out.println("                 VITAMINA PRONTA                  ");
            System.out.println("==================================================");
            System.out.println("Receita: Vitamina de " + item1 + " com " + item2 + ", batida com " + liquido + ", "
                    + item4 + " e finalizada com " + adocante + ".");
            System.out.println("Perfil atendido: " + perfil.toUpperCase() + ".");
            System.out.println("\n--- COMPOSIÇÃO QUÍMICA E BENEFÍCIOS DA VITAMINA ---");

            exibirNutricaoIngrediente(item1.toLowerCase());
            System.out.println();
            exibirNutricaoIngrediente(item2.toLowerCase());
            System.out.println();
            exibirNutricaoLiquido(liquido.toLowerCase());
            System.out.println();
            exibirNutricaoIngrediente(item4.toLowerCase());
            System.out.println();
            exibirNutricaoAdocante(adocante.toLowerCase());

            System.out.println("\nDica: Bata tudo no liquidificador com gelo por 1 minuto e sirva na hora!");
            System.out.println("==================================================");

            System.out.print("\nDeseja montar uma nova vitamina? (S/N): ");
            continuar = teclado.nextLine().toLowerCase().trim();

        } while (continuar.equals("s") || continuar.equals("sim"));

        System.out.println("\nPrograma encerrado. Bom apetite!");
        teclado.close();
    }

    public static void exibirNutricaoIngrediente(String nomeItem) {
        switch (nomeItem) {
            case "maçã":
            case "maca":
            case "maça":
                System.out.println("[MAÇÃ]");
                System.out.println(
                        "Elementos e Nutrientes: Potássio (K), Fósforo (P), Fibras (pectina), Vitamina C, Água (H2O) e antioxidantes.");
                System.out.println("Benefícios: Auxilia a digestão e ajuda no controle do colesterol.");
                break;

            case "banana":
                System.out.println("[BANANA]");
                System.out.println("Elementos e Nutrientes: Potássio (K), Magnésio (Mg), Vitamina B6 e carboidratos.");
                System.out.println("Benefícios: Fornece energia rápida e ajuda a prevenir cãibras.");
                break;

            case "uva":
                System.out.println("[UVA]");
                System.out.println(
                        "Elementos e Nutrientes: Ferro (Fe), Potássio (K), flavonoides, resveratrol, Vitaminas C e K.");
                System.out.println("Benefícios: Possui forte ação antioxidante e protege o coração.");
                break;

            case "morango":
                System.out.println("[MORANGO]");
                System.out.println(
                        "Elementos e Nutrientes: Manganês (Mn), Potássio (K), Vitamina C, flavonoides, fibras e antioxidantes.");
                System.out.println("Benefícios: Auxilia a imunidade e melhora a saúde da pele.");
                break;

            case "laranja":
                System.out.println("[LARANJA]");
                System.out.println(
                        "Elementos e Nutrientes: Cálcio (Ca), Potássio (K), Vitamina C, fibras e ácido cítrico.");
                System.out.println("Benefícios: Fortalece o sistema imunológico e melhora a absorção de ferro.");
                break;

            case "pera":
                System.out.println("[PERA]");
                System.out
                        .println("Elementos e Nutrientes: Potássio (K), Cobre (Cu), fibras, Vitamina C e Água (H2O).");
                System.out.println("Benefícios: Auxilia o funcionamento intestinal e hidrata o corpo.");
                break;

            case "abacate":
                System.out.println("[ABACATE]");
                System.out.println(
                        "Elementos e Nutrientes: Potássio (K), Magnésio (Mg), gorduras monoinsaturadas (ômega 9) e Vitamina E.");
                System.out
                        .println("Benefícios: Promove saciedade, protege o coração e melhora a absorção de vitaminas.");
                break;

            case "aveia":
                System.out.println("[AVEIA]");
                System.out.println(
                        "Elementos e Nutrientes: Ferro (Fe), Zinco (Zn), Magnésio (Mg), Fósforo (P) e fibras beta-glucanas.");
                System.out.println("Benefícios: Dá energia sustentada, regula o intestino e reduz o colesterol ruim.");
                break;

            case "mel":
                System.out.println("[MEL]");
                System.out.println(
                        "Elementos e Nutrientes: Potássio (K), Cálcio (Ca), Ferro (Fe), glicose, frutose e enzimas naturais.");
                System.out.println(
                        "Benefícios: Fonte imediata de energia, ação antimicrobiana e alívio para a garganta.");
                break;

            case "amendoim":
            case "amendoin":
                System.out.println("[AMENDOIM]");
                System.out.println(
                        "Elementos e Nutrientes: Magnésio (Mg), Fósforo (P), Potássio (K), proteínas, gorduras boas e Vitamina E.");
                System.out.println(
                        "Benefícios: Fornece alta energia, auxilia no ganho de massa muscular e dá saciedade.");
                break;

            case "castanha":
            case "castanha de caju":
                System.out.println("[CASTANHA]");
                System.out.println(
                        "Elementos e Nutrientes: Zinco (Zn), Ferro (Fe), Magnésio (Mg), Cobre (Cu) e gorduras monoinsaturadas.");
                System.out.println(
                        "Benefícios: Fortalece a imunidade, melhora a saúde óssea e protege o sistema cardiovascular.");
                break;

            case "castanha do para":
            case "castanha do pará":
            case "castanha-do-para":
            case "castanha-do-pará":
                System.out.println("[CASTANHA-DO-PARÁ]");
                System.out.println(
                        "Elementos e Nutrientes: Selênio (Se), Magnésio (Mg), Fósforo (P), Zinco (Zn) e Vitamina E.");
                System.out.println(
                        "Benefícios: Poderoso antioxidante, regula a tireoide e protege as células do cérebro.");
                break;

            case "semente de abobora":
            case "semente de abóbora":
            case "sementes de abobora":
            case "sementes de abóbora":
                System.out.println("[SEMENTE DE ABÓBORA]");
                System.out.println(
                        "Elementos e Nutrientes: Zinco (Zn), Magnésio (Mg), Ferro (Fe), Manganês (Mn) e triptofano.");
                System.out.println(
                        "Benefícios: Melhora a qualidade do sono, fortalece a imunidade e auxilia na recuperação muscular.");
                break;
            case "sementes":
            case "semente":
                System.out.println("[SEMENTES (Chia / Linhaça)]");
                System.out.println(
                        "Elementos e Nutrientes: Cálcio (Ca), Magnésio (Mg), Selênio (Se), Zinco (Zn), ômega-3 e fibras.");
                System.out.println("Benefícios: Ação anti-inflamatória, saúde cerebral e regulação intestinal.");
                break;
            case "kiwi":
            default:
                System.out.println("[" + nomeItem.toUpperCase() + "] - Ingrediente sem ficha química cadastrada.");
        }
    }
        // Método para bases líquidas (Leite, Água, Sucos)
    public static void exibirNutricaoLiquido(String nomeLiquido) {
        switch (nomeLiquido) {
            case "leite":
            case "leite integral":
            case "leite desnatado":
                System.out.println("[LEITE]");
                System.out.println("Elementos e Nutrientes: Cálcio (Ca), Fósforo (P), Potássio (K), proteínas, Vitaminas A, D e B12.");
                System.out.println("Benefícios: Fortalece ossos e dentes e auxilia na recuperação muscular.");
                break;

            case "agua":
            case "água":
                System.out.println("[ÁGUA]");
                System.out.println("Elementos e Nutrientes: Hidrogênio (H), Oxigênio (O) e traços de minerais (Sódio, Magnésio).");
                System.out.println("Benefícios: Hidratação pura, transporte de nutrientes e zero calorias.");
                break;

            case "agua de coco":
            case "água de coco":
                System.out.println("[ÁGUA DE COCO]");
                System.out.println("Elementos e Nutrientes: Potássio (K), Sódio (Na), Magnésio (Mg), Cálcio (Ca) e carboidratos leves.");
                System.out.println("Benefícios: Isotônico natural, repõe eletrólitos e evita desidratação.");
                break;

            case "suco de laranja":
                System.out.println("[SUCO DE LARANJA]");
                System.out.println("Elementos e Nutrientes: Potássio (K), Cálcio (Ca), Vitamina C, folato e flavonoides.");
                System.out.println("Benefícios: Impulsiona a imunidade e facilita a absorção de ferro das sementes.");
                break;

            case "suco de uva":
                System.out.println("[SUCO DE UVA INTEGRAL]");
                System.out.println("Elementos e Nutrientes: Ferro (Fe), Potássio (K), Manganês (Mn), resveratrol e polifenóis.");
                System.out.println("Benefícios: Melhora a circulação sanguínea, dá energia e combate radicais livres.");
                break;

            case "leite vegetal":
            case "leite de aveia":
            case "leite de amendoas":
            case "leite de amêndoas":
                System.out.println("[LEITE VEGETAL]");
                System.out.println("Elementos e Nutrientes: Cálcio (Ca - quando fortificado), Vitamina E, fibras e gorduras insaturadas.");
                System.out.println("Benefícios: Opção sem lactose, leve para a digestão e amiga do coração.");
                break;

            default:
                System.out.println("[" + nomeLiquido.toUpperCase() + "] - Base líquida sem ficha química cadastrada.");
        }
    }

    // Método para adoçantes e açúcares
    public static void exibirNutricaoAdocante(String nomeAdocante) {
        switch (nomeAdocante) {
            case "mel":
                System.out.println("[MEL]");
                System.out.println("Elementos e Nutrientes: Potássio (K), Cálcio (Ca), Ferro (Fe), glicose, frutose e enzimas naturais.");
                System.out.println("Perfil Nutricional: Energético natural. Fornece energia rápida e tem ação antimicrobiana.");
                break;

            case "acucar":
            case "açucar":
            case "açúcar":
            case "acucar refinado":
            case "açúcar refinado":
                System.out.println("[AÇÚCAR REFINADO]");
                System.out.println("Elementos e Nutrientes: Carbono (C), Hidrogênio (H) e Oxigênio (O) na forma de sacarose pura.");
                System.out.println("Perfil Nutricional: Caloria vazia de absorção imediata. Eleva rapidamente a glicose no sangue.");
                break;

            case "acucar mascavo":
            case "açucar mascavo":
            case "açúcar mascavo":
            case "acucar demerara":
            case "açúcar demerara":
                System.out.println("[AÇÚCAR MASCAVO / DEMERARA]");
                System.out.println("Elementos e Nutrientes: Ferro (Fe), Cálcio (Ca), Potássio (K), Magnésio (Mg) e sacarose.");
                System.out.println("Perfil Nutricional: Energético menos processado. Mantém minerais do caldo de cana.");
                break;

            case "adocante":
            case "adoçante":
            case "stevia":
            case "estevia":
            case "xilitol":
                System.out.println("[ADOÇANTE NATURAL (Stévia / Xilitol)]");
                System.out.println("Elementos e Nutrientes: Glicosídeos de esteviol ou polióis (Carbono, Hidrogênio e Oxigênio).");
                System.out.println("Perfil Nutricional: Baixa ou zero caloria. Não causa picos de insulina, ideal para controle glicêmico.");
                break;

            case "melado":
            case "melado de cana":
                System.out.println("[MELADO DE CANA]");
                System.out.println("Elementos e Nutrientes: Ferro (Fe), Cálcio (Ca), Magnésio (Mg), Potássio (K) e Vitaminas do complexo B.");
                System.out.println("Perfil Nutricional: Rico em ferro, excelente opção vegana para combater anemia e dar energia.");
                break;

            case "sem nada":
            case "nenhum":
            case "nao":
            case "não":
                System.out.println("[SEM ADIÇÃO DE AÇÚCAR]");
                System.out.println("Elementos e Nutrientes: Apenas os açúcares naturais (frutose) das próprias frutas.");
                System.out.println("Perfil Nutricional: Opção mais saudável, preserva o índice glicêmico baixo e o sabor natural.");
                break;

            default:
                System.out.println("[" + nomeAdocante.toUpperCase() + "] - Adoçante sem ficha química cadastrada.");
        }
    }

}
