public class TesteCarro {
    String marca;
    String modelo;
    int velocidade = 0;

    public static void main(String[] args) {
        TesteCarro fusca = new TesteCarro();
        fusca.marca = "Volkswagen";
        fusca.modelo = "Fusca";

        fusca.acelerar(40);
        fusca.exibir();

        fusca.frear(10);
        fusca.excluir();

        fusca.frear(100);
        fusca.exibir();
    }

    void acelerar(int valor) {
        velocidade += valor;
    }

    void frear(int valor) {
        velocidade -= valor;
        if (velocidade < 0) {
            velocidade = 0;
        }
    }

    void exibir() {
        System.out.println("Carro: " + marca + " " + modelo + " - Velocidade: " + velocidade);
    }

    void excluir() {
        marca = null;
        modelo = null;
        velocidade = 0;
        System.out.println("Carro excluído/resetado.");
    }
}
