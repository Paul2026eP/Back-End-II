class Cidade {
    private String nomeCidade;

    public Cidade(String nomeCidade) {
        this.nomeCidade = nomeCidade;}

    public String getNome() {
        return nomeCidade;  }
}

// Classe Aluno com papel de Principal 
public class Aluno {
    private String nome;
    private Cidade cidade; 

    public Aluno(String nome, Cidade cidade) {
        this.nome = nome;
        this.cidade = cidade;                }
        
    //publicação obtendo retorno    
    public String getNome() { return nome; }
    public Cidade getCidade() { return cidade; }

    // método para exibir() saída dentro da classe Aluno
    public void exibir() {
        System.out.println(nome + " mora em " + cidade.getNome());  }

    // O método main agora fica aqui dentro para execução 
    public static void main(String[] args) {
        Cidade londrina = new Cidade("Londrina");        
        Aluno aluno = new Aluno("Ana", londrina);

        aluno.exibir();  }
}
