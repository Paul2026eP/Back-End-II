// 2. Escola - Boletim de Alunos
import java.util.Locale;
import java.util.Scanner;

public class Aluno {
    private String nome;
    private double n1;
    private double n2;

    public Aluno(String nome, double n1, double n2) {
        this.nome = nome;
        this.n1 = n1;
        this.n2 = n2;
    }

    public double getMedia() {
        return (this.n1 + this.n2) / 2.0;
    }

    public String getSituacao() {
        double media = this.getMedia();
        if (media >= 7.0) return "Aprovado";
        if (media >= 5.0) return "Recuperação";
        return "Reprovado";
    }

    @Override
    public String toString() {
        return String.format("%s - Média: %.1f (%s)", this.nome, this.getMedia(), this.getSituacao());
    }
}

class Main {
    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Scanner scanner = new Scanner(System.in);
        
        Aluno[] alunos = new Aluno[4];
        int aprovados = 0, recuperacao = 0, reprovados = 0;

        for (int i = 0; i < alunos.length; i++) {
            System.out.println("Dados do aluno " + (i + 1) + ":");
            System.out.print("Nome: ");
            String nome = scanner.next();
            System.out.print("Nota 1: ");
            double n1 = scanner.nextDouble();
            System.out.print("Nota 2: ");
            double n2 = scanner.nextDouble();
            
            alunos[i] = new Aluno(nome, n1, n2);
            System.out.println();
        }

        System.out.println("--- RESULTADOS ---");
        for (Aluno a : alunos) {
            System.out.println(a);
            
            String sit = a.getSituacao();
            if (sit.equals("Aprovado")) aprovados++;
            else if (sit.equals("Recuperação")) recuperacao++;
            else reprovados++;
        }

        System.out.println("\n--- RESUMO FINAL ---");
        System.out.println("Aprovados: " + aprovados);
        System.out.println("Em Recuperação: " + recuperacao);
        System.out.println("Reprovados: " + reprovados);

        scanner.close();
    }
}