// 1. Empresa - Controle de Salários 

import java.util.Locale;
import java.util.Scanner;

public class Controle_de_Salarios {
    private int id;
    private double salario;

    public Controle_de_Salarios(int id, double salario) {
        this.id = id;
        this.salario = salario;
    }

    public double getSalario() {
        return this.salario;
    }

    public int getId() {
        return this.id;
    }

    @Override
    public String toString() {
        return String.format("Funcionário %d: R$ %.2f", this.id, this.salario);
    }
}

class Main {
    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Scanner scanner = new Scanner(System.in);
        
        Controle_de_Salarios[] funcionarios = new Controle_de_Salarios[5];
        double somaSalarios = 0.0;
        
        System.out.println("Digite o salário de 5 funcionários:");
        for (int i = 0; i < funcionarios.length; i++) {
            System.out.print("Funcionário " + (i + 1) + ": R$ ");
            double salarioDigitado = scanner.nextDouble();
            
            funcionarios[i] = new Controle_de_Salarios((i + 1), salarioDigitado);
            somaSalarios += funcionarios[i].getSalario();
        }
        
        System.out.println("\n--- Salários Cadastrados ---");
        for (Controle_de_Salarios f : funcionarios) {
            System.out.println(f);
        }
        
        double mediaSalarial = somaSalarios / funcionarios.length;
        System.out.printf("\nMédia salarial da empresa: R$ %.2f%n", mediaSalarial);
        
        double maiorSalario = funcionarios[0].getSalario();
        int acimaDaMedia = 0;
        
        for (Controle_de_Salarios f : funcionarios) {
            if (f.getSalario() > maiorSalario) {
                maiorSalario = f.getSalario();
            }
            if (f.getSalario() > mediaSalarial) {
                acimaDaMedia++;
            }
        }
        
        System.out.println("Quantidade de funcionários acima da média: " + acimaDaMedia);
        System.out.printf("Maior salário encontrado: R$ %.2f%n", maiorSalario);
        
        System.out.println("\n--- Classificação dos Salários ---");
        for (Controle_de_Salarios f : funcionarios) {
            String classificacao;
            double sal = f.getSalario();
            
            if (sal < 2000.00) {
                classificacao = "Salário baixo";
            } else if (sal <= 5000.00) {
                classificacao = "Salário médio";
            } else {
                classificacao = "Salário alto";
            }
            System.out.printf("Funcionário %d (R$ %.2f): %s%n", f.getId(), sal, classificacao);
        }
        
        scanner.close();
    }
}
