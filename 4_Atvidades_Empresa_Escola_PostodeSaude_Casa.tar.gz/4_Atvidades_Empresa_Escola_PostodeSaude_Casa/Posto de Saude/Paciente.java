// 3. Posto de Saúde- Triagem de Pacientes 

import java.util.Locale;
import java.util.Scanner;

public class Paciente {
    private String nome;
    private int idade;
    private double temperatura;

    public Paciente(String nome, int idade, double temperatura) {
        this.nome = nome;
        this.idade = idade;
        this.temperatura = temperatura;
    }

    public String getClassificacao() {
        if (this.idade >= 65 || this.temperatura >= 39.0) {
            return "Atendimento prioritário";
        } else if (this.temperatura >= 37.5 && this.temperatura <= 38.9) {
            return "Atendimento normal com observação";
        } else {
            return "Atendimento normal";
        }
    }

    @Override
    public String toString() {
        return String.format("Paciente: %s | Idade: %d | Temp: %.1f °C -> %s", 
                this.nome, this.idade, this.temperatura, this.getClassificacao());
    }
}

class Main {
    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Scanner scanner = new Scanner(System.in);
        
        Paciente[] pacientes = new Paciente[5];

        for (int i = 0; i < pacientes.length; i++) {
            System.out.println("Dados do paciente " + (i + 1) + ":");
            
            System.out.print("Nome: ");
            // 1. Alterado para nextLine() para aceitar nomes com espaços (ex: Maria da Gloria)
            String nome = scanner.nextLine(); 
            
            System.out.print("Idade: ");
            int id = scanner.nextInt();
            
            System.out.print("Temperatura (°C): ");
            double temp = scanner.nextDouble();
            
            // 2. Limpa o buffer do teclado (consome o "Enter" que sobra após ler o double)
            scanner.nextLine(); 
            
            pacientes[i] = new Paciente(nome, id, temp);
            System.out.println();
        }

        System.out.println("--- RELATÓRIO DE TRIAGEM ---");
        for (Paciente p : pacientes) {
            System.out.println(p);
        }

        scanner.close();
    }
}
