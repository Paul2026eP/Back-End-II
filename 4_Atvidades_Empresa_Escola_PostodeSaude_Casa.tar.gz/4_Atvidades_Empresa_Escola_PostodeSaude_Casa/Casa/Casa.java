public class Casa {
    private Comodo[] comodos;

    class Comodo {
        private String nome;
        public Comodo(String nome) { this.nome = nome; }
        public String getNome() {  return nome; }
    }

    public Casa(String[] nomesDosComodos) {
        comodos = new Comodo[nomesDosComodos.length];
        for (int i = 0; i < nomesDosComodos.length; i++) {
            comodos[i] = new Comodo(nomesDosComodos[i]);
        }
    }

    public void listar() {
        System.out.println("--- LISTAGEM DOS COMODOS DA CASA ---");
        for (Comodo c : comodos) {
            System.out.println("Comodo: " + c.getNome());
        }
    }

    public static void main(String[] args) {
        String[] listaNomes = {
            "Calçada e Fachada",
            "Jardim",
            "Casa",
            "Sala de EStar",
            "Sala de Jantar",
            "Quarto Casal",
            "Quarto Solteiro",
            "Banheiro Casal",
            "Banheiro Solteiro",
            "Closet"
        };

        Casa minhaCasa = new Casa(listaNomes);
        minhaCasa.listar();
    }
}
