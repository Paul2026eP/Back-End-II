public class ContaBancaria {
    private final String titular;
    private double saldo;

    public ContaBancaria(String titular, double saldoInicial) {
        if (titular == null || titular.trim().isEmpty()) {
            throw new IllegalArgumentException("Titular obrigatório");}
        if (saldoInicial < 0) {
            throw new IllegalArgumentException("Saldo inicial inválido");}
        this.titular = titular;
        this.saldo = saldoInicial;}

    public String getTitular() {
        return titular;}
    public double getSaldo() {
        return saldo;}
    public void depositar(double valor) {
        if (valor <= 0) {
            throw new IllegalArgumentException("O valor do depósito deve ser positivo");}
        this.saldo += valor;}
    public void sacar(double valor) {
        if (valor <= 0) {
            throw new IllegalArgumentException("O valor do saque deve ser positivo");}
        if (valor > this.saldo) {
            throw new IllegalArgumentException("Saldo insuficiente para realizar a operação");}
        this.saldo -= valor;}
    public static void main(String[] args) {
        try {
            ContaBancaria conta = new ContaBancaria("João Silva", 500.00);
            System.out.println("--- Conta Criada ---");
            System.out.println("Titular: " + conta.getTitular());
            System.out.println("Saldo Inicial: R$ " + conta.getSaldo());

            System.out.println("\n--- Depositando R$ 200,00 ---");
            conta.depositar(200.00);
            System.out.println("Novo Saldo: R$ " + conta.getSaldo());

            System.out.println("\n--- Sacando R$ 150,00 ---");
            conta.sacar(150.00);
            System.out.println("Novo Saldo: R$ " + conta.getSaldo());

            System.out.println("\n--- Tentando sacar R$ 1000,00 ---");
            conta.sacar(1000.00);

        } catch (IllegalArgumentException e) {
            System.err.println("Erro na operação: " + e.getMessage());
        }
    }
}
