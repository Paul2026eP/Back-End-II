import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
//para rodar cd "/home/escola/Músicas/AV-Java/" && javac AssistenteVirtual.java && java AssistenteVirtual
 
public class AssistenteVirtual {

    private static double saldoGeral = 15250.00;
    private static List<String> tarefasAdmin = new ArrayList<>();
    private static List<String> historicoTransacoes = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean executando = true;

        tarefasAdmin.add("Revisar contratos de fornecedores - Prazo: 10/10");
        tarefasAdmin.add("Aprovar folhas de pagamento do setor comercial");
        historicoTransacoes.add("Recebimento Cliente A: +R$ 5.000,00");
        historicoTransacoes.add("Pagamento Luz/Internet: -R$ 450,00");

        System.out.println("====================================================");
        System.out.println("🤖 Assistente Virtual Empresarial (Finanças & Admin)");
        System.out.println("====================================================");
        System.out.println("Olá! Sou seu assistente corporativo. Como posso ajudar hoje?");

        while (executando) {
            System.out.println("\n[ MENU PRINCIPAL ]");
            System.out.println("1. Acessar Módulo Financeiro");
            System.out.println("2. Acessar Módulo Administrativo");
            System.out.println("3. Resumo Executivo do Dia");
            System.out.println("4. Encerrar Assistente");
            System.out.print("Escolha uma opção: ");

            int opcao = lerOpcaoInteira(scanner);

            switch (opcao) {
                case 1:
                    menuFinanceiro(scanner);
                    break;
                case 2:
                    menuAdministrativo(scanner);
                    break;
                case 3:
                    exibirResumoGeral();
                    break;
                case 4:
                    System.out.println("\nEncerrando atividades. Relatório diário salvo com sucesso. Até logo!");
                    executando = false;
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
        scanner.close();
    }

    private static void menuFinanceiro(Scanner scanner) {
        boolean voltar = false;
        while (!voltar) {
            System.out.println("\n📈 [ MÓDULO FINANCEIRO ]");
            System.out.println("1. Consultar Saldo Atual");
            System.out.println("2. Lançar Nova Entrada/Saída");
            System.out.println("3. Ver Histórico de Transações");
            System.out.println("4. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");

            int opcao = lerOpcaoInteira(scanner);

            switch (opcao) {
                case 1:
                    System.out.printf("💰 Saldo Geral Consolidado: R$ %.2f\n", saldoGeral);
                    break;
                case 2:
                    System.out.print("Digite a descrição da transação: ");
                    scanner.nextLine();
                    String desc = scanner.nextLine();
                    System.out.print("Digite o valor (positivo para entrada, negativo para saída): ");
                    double valor = scanner.nextDouble();
                    
                    saldoGeral += valor;
                    String tipo = valor >= 0 ? "Entrada" : "Saída";
                    historicoTransacoes.add(desc + ": " + (valor >= 0 ? "+" : "") + "R$ " + valor);
                    System.out.printf("✅ %s lançada com sucesso! Novo saldo: R$ %.2f\n", tipo, saldoGeral);
                    break;
                case 3:
                    System.out.println("\n📋 Extrato Recente:");
                    for (String t : historicoTransacoes) {
                        System.out.println(" - " + t);
                    }
                    break;
                case 4:
                    voltar = true;
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        }
    }

    private static void menuAdministrativo(Scanner scanner) {
        boolean voltar = false;
        while (!voltar) {
            System.out.println("\n💼 [ MÓDULO ADMINISTRATIVO ]");
            System.out.println("1. Listar Pendências e Tarefas");
            System.out.println("2. Adicionar Nova Tarefa");
            System.out.println("3. Concluir Próxima Tarefa");
            System.out.println("4. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");

            int opcao = lerOpcaoInteira(scanner);

            switch (opcao) {
                case 1:
                    System.out.println("\n📌 Tarefas Administrativas Pendentes:");
                    if (tarefasAdmin.isEmpty()) {
                        System.out.println("Nenhuma tarefa pendente no momento.");
                    } else {
                        // Correção efetuada aqui: loop limpo usando tarefasAdmin.size()
                        for (int i = 0; i < tarefasAdmin.size(); i++) {
                            System.out.printf("%d. %s\n", (i + 1), tarefasAdmin.get(i));
                        }
                    }
                    break;
                case 2:
                    System.out.print("Descreva a nova tarefa/compromisso: ");
                    scanner.nextLine();
                    String novaTarefa = scanner.nextLine();
                    tarefasAdmin.add(novaTarefa);
                    System.out.println("✅ Tarefa adicionada à agenda da equipe.");
                    break;
                case 3:
                    if (!tarefasAdmin.isEmpty()) {
                        String removida = tarefasAdmin.remove(0);
                        System.out.println("🎉 Tarefa concluída e arquivada: " + removida);
                    } else {
                        System.out.println("Não há tarefas para concluir.");
                    }
                    break;
                case 4:
                    voltar = true;
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        }
    }

    private static void exibirResumoGeral() {
        System.out.println("\n📊 [ INSIGHTS DO ASSISTENTE - RESUMO EXECUTIVO ]");
        System.out.printf("• Saúde Financeira: Saldo atualizado em R$ %.2f\n", saldoGeral);
        System.out.printf("• Operações Administrativas: Você possui %d tarefa(s) pendente(s) hoje.\n", tarefasAdmin.size());
        if (saldoGeral < 5000) {
            System.out.println("⚠️ Alerta do Assistente: O saldo está abaixo do limite prudencial recomendado.");
        } else {
            System.out.println("🟢 Status: Operação financeira e administrativa estável.");
        }
    }

    private static int lerOpcaoInteira(Scanner scanner) {
        while (!scanner.hasNextInt()) {
            System.out.println("Por favor, digite um número válido.");
            scanner.next();
        }
        return scanner.nextInt();
    }
}
