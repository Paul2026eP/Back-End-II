import java.util.Scanner;

public class CalculadoradeIdadeemDias {

    public static void main(String[] args) {
        // Criando o objeto Scanner para ler o que o usuário digita no terminal
        Scanner entrada = new Scanner(System.in);

        System.out.println("=== CALCULADORA DE DIAS VIVIDOS ===");
        System.out.print("Digite a sua idade: ");
        
        // Lê o número inteiro digitado pelo usuário
        int idade = entrada.nextInt();

        // Realiza o cálculo aproximado (idade multiplicada por 365 dias)
        int diasVividos = idade * 365;

        // Exibe o resultado formatado na tela
        System.out.println("Você já viveu aproximadamente " + diasVividos + " dias.");

        // Fecha o scanner para liberar os recursos do sistema (Boa prática de mercado)
        entrada.close();
    }
}
