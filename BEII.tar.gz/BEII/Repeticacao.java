public class Repeticacao {
    public static void main (String[] args){
        //for: sabemos quantas vezes repetir
        for (int i=1; i<=3; i++) {
            System.out.println("Volta " + i);
        }
        //while: repetimos enquanto a condição for verdadeira
        int tentativa = 1;
        while (tentativa <= 3) {
            System.out.println("Tentativa " + tentativa);
            tentativa++;
        }
    }
}