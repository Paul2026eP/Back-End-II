package com.bigdata.analytics;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MiniBigDataEngine {

    // Constantes de configuração do ambiente de Big Data
    private static final int TOTAL_REGISTROS_DATA_LAKE = 50_000; // Simula volumetria
    private static final int TAMANHO_DO_LOTE = 10_000;          // Tamanho do Chunk (Paginação)

    public static void main(String[] args) {
        System.out.println("=== [INICIALIZANDO ENGINE MINI BIG DATA] ===");
        System.out.println("Buscando massa de dados bruta no Data Lake...");
        
        long tempoInicio = System.currentTimeMillis();

        // 1. USO DO 'WHILE': Simulando Streaming de Dados Paginados do Data Lake
        // Essencial em Big Data para não carregar milhões de registros de uma vez só na memória.
        int ponteiroLeitura = 0;
        double faturamentoTotalGeral = 0.0;
        int totalTransacoesFraude = 0;

        while (ponteiroLeitura < TOTAL_REGISTROS_DATA_LAKE) {
            System.out.printf("[ETL] Extraindo lote: Registros de %d até %d...%n", 
                    ponteiroLeitura, (ponteiroLeitura + TAMANHO_DO_LOTE));
            
            // Extração (Extract)
            List<String[]> loteBruto = simularLeituraDataLake(ponteiroLeitura, TAMANHO_DO_LOTE);

            // Transformação e Carga Analítica (Transform & Load)
            // 2. USO DO 'FOR': Iterando de forma extremamente rápida sobre o lote em memória
            for (String[] linhaCsv : loteBruto) {
                // Mapeamento dos dados do CSV Fake: [ID, VALOR, STATUS]
                double valorTransacao = Double.parseDouble(linhaCsv[1]);
                String statusTransacao = linhaCsv[2];

                // Agregação Analítica (MapReduce Manual)
                faturamentoTotalGeral += valorTransacao;
                
                if ("FRAUDE_SUSPEITA".equals(statusTransacao)) {
                    totalTransacoesFraude++;
                }
            }

            // Desloca o ponteiro para ler o próximo bloco de Big Data
            ponteiroLeitura += TAMANHO_DO_LOTE;
        }

        long tempoFim = System.currentTimeMillis();

        //=== PIPELINE CONCLUÍDO: IMPRESSÃO DOS INSIGHTS BI / DASHBOARD ===
        System.out.println("\n=== [PIPELINE DE DATA ANALYTICS CONCLUÍDO] ===");
        System.out.printf("Total de registros processados : %,d %n", TOTAL_REGISTROS_DATA_LAKE);
        System.out.printf("Volume Total Transacionado     : R$ %,.2f %n", faturamentoTotalGeral);
        System.out.printf("Alertas de Fraude Detectados   : %d anomalias %n", totalTransacoesFraude);
        System.out.printf("Tempo de Execução da Engine    : %d ms %n", (tempoFim - tempoInicio));
        System.out.println("=================================================");
    }

    /**
     * Método auxiliar para simular uma fonte de Big Data (ex: arquivos CSV massivos no AWS S3).
     * Retorna uma lista de Arrays de Strings representando as colunas.
     */
    private static List<String[]> simularLeituraDataLake(int inicio, int quantidade) {
        List<String[]> dadosBrutos = new ArrayList<>();
        Random random = new Random();
        String[] statusOpcoes = {"APROVADO", "APROVADO", "APROVADO", "FRAUDE_SUSPEITA"};

        for (int i = 0; i < quantidade; i++) {
            int id = inicio + i;
            double valor = 10.0 + (1500.0 * random.nextDouble()); // Valores aleatórios
            String status = statusOpcoes[random.nextInt(statusOpcoes.length)];
            
            // Simula uma linha de um arquivo de texto/CSV separado por vírgula
            dadosBrutos.add(new String[]{String.valueOf(id), String.valueOf(valor), status});
        }
        return dadosBrutos;
    }
}
