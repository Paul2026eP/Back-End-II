package com.empresa.sistemacorporativo.service;

import java.util.ArrayList;
import java.util.List;

// 1. ANOTAÇÃO DE MERCADO: Em um projeto Spring Boot real, usaríamos @Service aqui
public class RelatorioVendasService {
    
    // CORREÇÃO: Método main preenchido para testar e executar a classe corporativa
    public static void main(String[] args) {
        // Criando a lista de dados de teste (Simulando o JSON que viria da Web)
        List<VendaDTO> dadosDaApi = new ArrayList<>();
        dadosDaApi.add(new VendaDTO(1L, "Licenças de Software ERP", 15000.0, "B2B"));
        dadosDaApi.add(new VendaDTO(2L, "Teclado Mecânico", 350.0, "B2C"));
        dadosDaApi.add(new VendaDTO(3L, "Servidores Cloud", 50000.0, "B2B"));

        // Instanciando a classe de serviço
        RelatorioVendasService service = new RelatorioVendasService();
        
        System.out.println("=== SISTEMA WEB: RECEBENDO REQUISIÇÃO HTTP ===");
        // Chamando o método que contém a lógica do FOR e do WHILE
        List<VendaDTO> resultados = service.processarImportacaoWeb(dadosDaApi);
        
        System.out.println("\n=== RETORNO DA API (JSON RESPOSTA) ===");
        for (VendaDTO venda : resultados) {
            System.out.println("Produto: " + venda.getProduto() 
                    + " | Valor Final: R$" + venda.getValor() 
                    + " | Obs: " + venda.getObservacao());
        }
    }

    /**
     * Simula um endpoint ou método de serviço que processa vendas enviadas via API Web.
     * @param vendasBrutas Lista de vendas recebidas no corpo da requisição (JSON mapeado para Objeto)
     * @return Lista de vendas processadas com regras de negócio aplicadas
     */
    public List<VendaDTO> processarImportacaoWeb(List<VendaDTO> vendasBrutas) {
        List<VendaDTO> vendasProcessadas = new ArrayList<>();

        // --- USO DO 'FOR' (Enhanced For): Processamento em lote de payloads HTTP ---
        System.out.println("[LOG LOGISTICA] Iniciando iteração sobre o payload recebido da Web...");
        
        for (VendaDTO venda : vendasBrutas) {
            // Regra de negócio: Se o cliente é corporativo (B2B) e comprou volume alto, ganha desconto
            if ("B2B".equalsIgnoreCase(venda.getTipoCliente()) && venda.getValor() > 10000.0) {
                double valorComDesconto = venda.getValor() * 0.90; // 10% de desconto
                venda.setValor(valorComDesconto);
                venda.setObservacao("Desconto B2B aplicado automaticamente via API.");
            }
            vendasProcessadas.add(venda);
        }

        // --- USO DO 'WHILE': Consumo paginado de APIs externas ou buffers de upload ---
        System.out.println("[LOG INTEGRAÇÃO] Sincronizando dados com o sistema ERP externo...");
        
        int paginaAtual = 1;
        boolean possuiMaisPaginas = true;

        while (possuiMaisPaginas) {
            // Simula uma chamada HTTP para outro microserviço corporativo (ex: ERP de estoque)
            possuiMaisPaginas = integrarComErpExterno(paginaAtual, vendasProcessadas);
            
            System.out.println("[WEB CLIENT] Página " + paginaAtual + " processada e integrada com sucesso.");
            paginaAtual++; // Avança para a próxima página do lote
        }

        return vendasProcessadas;
    }

    // Método auxiliar simulando integração de rede (Web Client / RestTemplate)
    private boolean integrarComErpExterno(int pagina, List<VendaDTO> dados) {
        return pagina < 3; 
    }
}

/**
 * Padrão DTO (Data Transfer Object)
 */
class VendaDTO {
    private Long id;
    private String produto;
    private double valor;
    private String tipoCliente; 
    private String observacao;

    public VendaDTO(Long id, String produto, double valor, String tipoCliente) {
        this.id = id;
        this.produto = produto;
        this.valor = valor;
        this.tipoCliente = tipoCliente;
        this.observacao = "Sem observações.";
    }

    public Long getId() { return id; }
    public String getProduto() { return produto; }
    public double getValor() { return valor; }
    public void setValor(double valor) { this.valor = valor; }
    public String getTipoCliente() { return tipoCliente; }
    public String getObservacao() { return observacao; }
    public void setObservacao(String observacao) { this.observacao = observacao; }
}
