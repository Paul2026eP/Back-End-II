public class Vetores {
    public static void main(String[] args) {
        double[] notas = { 8.0, 9.0, 7.0};  // 3 posições (8, 1, 2)
        double soma = 0;
        for (int i=0; i <notas.length; i++){
            soma = soma + notas[i];
        }
    System.err.println("Média: " + (soma / notas.length));

    }
}
