import java.util.ArrayList;
import java.util.List;

public class SistemaBancario {

    public static void main(String[] args) {
        // --- CENÁRIO 1: USO DO 'FOR' (Processamento de Lote / Pix Agendados) ---
        List<Transferencia> lotePix = new ArrayList<>();
        lotePix.add(new Transferencia("Agência 01", "Conta 123", 1500.00));
        lotePix.add(new Transferencia("Agência 02", "Conta 456", 450.50));
        lotePix.add(new Transferencia("Agência 01", "Conta 789", 8000.00));

        System.out.println("=== INICIANDO PROCESSAMENTO DE LOTE PIX ===");
        // O 'for' (enhanced) é o padrão para iterar e aplicar regras de negócio em listas fixas
        for (Transferencia transacao : lotePix) {
            if (transacao.getValor() > 5000.00) {
                System.out.println("[ALERTA COMPLIANCE] Transferência para " + transacao.getContaDestino() 
                        + " no valor de R$" + transacao.getValor() + " retida para análise de fraude.");
            } else {
                System.out.println("[SUCESSO] R$" + transacao.getValor() + " enviado para " + transacao.getContaDestino());
            }
        }

        // --- CENÁRIO 2: USO DO 'WHILE' (Tentativas de Autenticação no ATM) ---
        System.out.println("\n=== CAIXA ELETRÔNICO: VALIDAÇÃO DE ACESSO ===");
        
        int tentativasRestantes = 3;
        boolean loginSucesso = false;
        
        // O 'while' monitora uma condição que muda dinamicamente baseada em eventos externos
        while (tentativasRestantes > 0 && !loginSucesso) {
            System.out.println("[SISTEMA] Validando credenciais... (Tentativas restantes: " + tentativasRestantes + ")");
            
            // Simulação de entrada do usuário ou checagem de banco de dados
            boolean senhaCorreta = simularValidacaoSenha(tentativasRestantes);

            if (senhaCorreta) {
                loginSucesso = true;
                System.out.println("[SUCESSO] Acesso liberado. Bem-vindo ao Internet Banking!");
            } else {
                tentativasRestantes--;
                System.out.println("[ERRO] Senha incorreta.");
            }
        }

        if (!loginSucesso) {
            System.out.println("[BLOQUEIO] Cartão retido por excesso de tentativas incorretas. Contate o gerente.");
        }
    }

    // Método auxiliar apenas para simular a dinâmica do WHILE
    private static boolean simularValidacaoSenha(int tentativa) {
        // Simula que o usuário errou as duas primeiras e acertou na última se restasse apenas 1
        return tentativa == 1; 
    }
}

// Classe que representa a entidade de Transferência Bancária (Padrão DTO/POJO)
class Transferencia {
    private String agenciaDestino;
    private String contaDestino;
    private double valor;

    public Transferencia(String agenciaDestino, String contaDestino, double valor) {
        this.agenciaDestino = agenciaDestino;
        this.contaDestino = contaDestino;
        this.valor = valor; 
    }

    public String getAgenciaDestino() { return agenciaDestino; }
    public String getContaDestino() { return contaDestino; }
    public double getValor() { return valor; }
}
