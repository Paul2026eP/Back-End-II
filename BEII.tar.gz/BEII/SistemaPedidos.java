import java.util.ArrayList;
import java.util.List;

public class SistemaPedidos {

    public static void main(String[] args) {
        // Criando uma lista de pedidos (Simulação de dados do mercado)
        List<Pedido> filaPedidos = new ArrayList<>();
        filaPedidos.add(new Pedido(101, "Notebook", 2));
        filaPedidos.add(new Pedido(102, "Mouse Sem Fio", 5));
        filaPedidos.add(new Pedido(103, "Monitor 4K", 1));

        // 1. USO DO 'FOR' (Ideal para coleções e tamanhos conhecidos)
        System.out.println("--- Relatório de Pedidos Recebidos ---");
        for (Pedido pedido : filaPedidos) {
            System.out.println("ID: " + pedido.getId() + " | Item: " + pedido.getProduto() + " | Qtd: " + pedido.getQuantidade());
        }

        // 2. USO DO 'WHILE' (Ideal para fluxos baseados em condições ou filas)
        System.out.println("\n--- Processando Fila de Envio ---");
        int estoqueDisponivel = 6; // Limite de itens que a expedição pode enviar hoje

        while (!filaPedidos.isEmpty() && estoqueDisponivel > 0) {
            // Remove o primeiro pedido da fila (FIFO)
            Pedido pedidoAtual = filaPedidos.remove(0); 

            if (pedidoAtual.getQuantidade() <= estoqueDisponivel) {
                estoqueDisponivel -= pedidoAtual.getQuantidade();
                System.out.println("[SUCESSO] Pedido #" + pedidoAtual.getId() + " enviado para transporte.");
            } else {
                System.out.println("[RETIDO] Pedido #" + pedidoAtual.getId() + " aguardando reposição de estoque.");
                // Em um sistema real, o pedido voltaria para a fila ou backend
            }
        }
        
        System.out.println("\nProcessamento finalizado. Itens restantes no estoque de hoje: " + estoqueDisponivel);
    }
}

// Classe de suporte padrão de mercado (Encapsulamento POJO)
class Pedido {
    private int id;
    private String produto;
    private int quantidade;

    public Pedido(int id, String produto, int quantidade) {
        this.id = id;
        this.produto = produto;
        this.quantidade = quantidade;
    }

    public int getId() { return id; }
    public String getProduto() { return produto; }
    public int getQuantidade() { return quantidade; }
}
