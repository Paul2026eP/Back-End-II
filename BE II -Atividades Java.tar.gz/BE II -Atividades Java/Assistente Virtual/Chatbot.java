import java.util.Scanner;

public class Chatbot {
    public static void main(String[] args) {
        // Inicializa o Scanner para ler a entrada do usuário no terminal
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("==================================================");
        System.out.println("🤖 Assistente Virtual: Olá! Sou o seu Chatbot.");
        System.out.println("Como posso te ajudar hoje? (Digite 'sair' para encerrar)");
        System.out.println("==================================================");

        while (true) {
            System.out.print("\nVocê: ");
            String mensagemUsuario = scanner.nextLine().trim().toLowerCase();

            // Condição de parada do Chatbot
            if (mensagemUsuario.equals("sair") || mensagemUsuario.equals("tchau")) {
                System.out.println("🤖 Assistente Virtual: Até logo! Tenha um ótimo dia.");
                break;
            }

            // Lógica de respostas estruturada por regras
            String respostaBot = obterResposta(mensagemUsuario);
            System.out.println("🤖 Assistente Virtual: " + respostaBot);
        }

        scanner.close();
    }

    /**
     * Retorna uma resposta com base nas palavras-chave digitadas pelo usuário.
     */
    private static String obterResposta(String mensagem) {
        if (mensagem.isEmpty()) {
            return "Você está aí? Digite algo para conversarmos!";
        } else if (mensagem.contains("ola") || mensagem.contains("oi") || mensagem.contains("bom dia")) {
            return "Olá! Tudo bem com você? O que te traz por aqui?";
        } else if (mensagem.contains("seu nome") || mensagem.contains("quem e voce")) {
            return "Eu sou o JavaBot, um protótipo de chatbot rodando no VS Code!";
        } else if (mensagem.contains("como voce funciona")) {
            return "Eu analiso o que você digita e procuro palavras-chave para responder usando estruturas de decisão!";
        } else if (mensagem.contains("ajuda") || mensagem.contains("suporte")) {
            return "Claro! Posso te ajudar explicando códigos, conversando ou respondendo dúvidas básicas.";
        } else if (mensagem.contains("java")) {
            return "Java é uma excelente linguagem de programação, amplamente utilizada no mercado corporativo e no Android.";
        } else if (mensagem.contains("tudo bem") || mensagem.contains("como vai")) {
            return "Comigo está tudo ótimo! Sou apenas linhas de código, mas funcionando 100%. E com você?";
        } else {
            return "Desculpe, ainda não sei como responder a isso. Pode tentar perguntar de outra forma?";
        }
    }
}
