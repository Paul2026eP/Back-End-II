class Cidade {
    private String nomeCidade;

    public Cidade(String nomeCidade) {
        this.nomeCidade = nomeCidade;
    }

    public String getNome() {
        return nomeCidade;
    }
}

public class Aluno {
    private String nome;
    private Cidade cidade; 

    public Aluno(String nome, Cidade cidade) {
        this.nome = nome;
        this.cidade = cidade;
    }

    public String getNome() {
        return nome;
    }

    
    public Cidade getCidade() {
        return cidade;
    }

    public void exibir() {
        System.out.println(nome + " mora em " + cidade.getNome());
    }
}


class Principal {
    public static void main(String[] args) {
        Cidade londrina = new Cidade("Londrina");
        Aluno aluno = new Aluno("Ana", londrina);

        aluno.exibir(); 
    }
}
