public class ContaBancaria {
    private final String titular;
    private double saldo;

    public ContaBancaria(String titular, double saldoInicial) {
        if (titular == null || titular.trim().isEmpty()) {
            throw new IllegalArgumentException("Titular obrigatório");
        }
        if (saldoInicial < 0) {
            throw new IllegalArgumentException("Saldo inicial inválido");
        }
        this.titular = titular;
        this.saldo = saldoInicial;
    }

    public String getTitular() {
        return titular;
    }
    
    public double getSaldo() {
        return saldo;
    }
    
    public void depositar(double valor) {
        if (valor <= 0) {
            throw new IllegalArgumentException("O valor do depósito deve ser positivo");
        }
        this.saldo += valor;
    }
    
    public void sacar(double valor) {
        if (valor <= 0) {
            throw new IllegalArgumentException("O valor do saque deve ser positivo");
        }
        if (valor > this.saldo) {
            throw new IllegalArgumentException("Saldo insuficiente para realizar a operação");
        }
        this.saldo -= valor;
    }

    // Transferência
    public boolean transferir(ContaBancaria destino, double valor) {
        if (valor <= 0) {
            System.out.println("Erro: O valor da transferência deve ser positivo.");
            return false;
        }
        if (valor > this.saldo) {
            System.out.println("Erro: Saldo insuficiente para transferir R$ " + valor);
            return false;
        }
        
        this.sacar(valor);
        destino.depositar(valor);
        return true;
    }

    public static void main(String[] args) {
        try {
            ContaBancaria conta1 = new ContaBancaria("João Silva", 500.00);
            ContaBancaria conta2 = new ContaBancaria("Maria Souza", 200.00);

            System.out.println("--- Saldos Iniciais ---");
            System.out.println(conta1.getTitular() + ": R$ " + conta1.getSaldo());
            System.out.println(conta2.getTitular() + ": R$ " + conta2.getSaldo());

            System.out.println("\n--- Depositando R$ 200,00 ---");
            conta1.depositar(200.00);
            System.out.println("Novo Saldo: R$ " + conta1.getSaldo());

            // Transferência
            double valorTransferencia = 150.00;
            System.out.println("\n--- Transferindo R$ " + valorTransferencia + " de João para Maria ---");
            
            boolean sucesso = conta1.transferir(conta2, valorTransferencia);
            
            if (sucesso) {
                System.out.println("Transferência realizada com sucesso!");
            } else {
                System.out.println("Falha na transferência.");
            }

            // Saldos finais
            System.out.println("\n--- Saldos Finais ---");
            System.out.println(conta1.getTitular() + ": R$ " + conta1.getSaldo());
            System.out.println(conta2.getTitular() + ": R$ " + conta2.getSaldo());

        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
