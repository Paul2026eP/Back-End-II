
class Funcionario {
 
    private String nome;
    private double salario;

    public Funcionario() {
    }

    public Funcionario(String nome, double salario) {
        this.nome = nome;
        this.salario = salario;
    }

    public void aumentarSalario(double porcentagem) {
        this.salario = this.salario + this.salario * (porcentagem / 100);
    }

    public double calcularSalarioAnual() {
        return this.salario * 13;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
}

public class Main {
    public static void main(String[] args) {
        Funcionario f1 = new Funcionario("Ana Silva", 3000.0);

        Funcionario f2 = new Funcionario();
        f2.setNome("Carlos Souza");
        f2.setSalario(4500.0);

        f1.aumentarSalario(10); 

        System.out.printf("Salário Anual de %s: R$ %.2f\n", f1.getNome(), f1.calcularSalarioAnual());
        System.out.printf("Salário Anual de %s: R$ %.2f\n", f2.getNome(), f2.calcularSalarioAnual());
    }
}
