public class ExemploSaldo {
    public static void main(String[] args) {
        String nome1 = "João Silva";
        double saldo1 = 550.0;

        String nome2 = "Maria Souza";
        double saldo2 = 350.0;

        System.out.println("--- Saldos Finais ---");
        
        // Usando printf para formatar a saída
        System.out.printf("%s: R$ %.2f%n", nome1, saldo1);
        System.out.printf("%s: R$ %.2f%n", nome2, saldo2);
    }
}
