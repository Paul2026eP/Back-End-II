public class Main {
    public static void main(String[] args) {
        Produto p1 = new Produto("Caderno", 15.50, 10);

        System.out.println("--- Teste Inicial ---");
        System.out.println("Produto: " + p1.getNome() + " | Preço: R$" + p1.getPreco() + " | Estoque: " + p1.getQuantidade());

        System.out.println("\n--- Teste Preço Negativo ---");
        p1.setPreco(-5.0); // Deve rejeitar e manter 15.50
        System.out.println("Preço atual após tentativa de erro: R$" + p1.getPreco());

        System.out.println("\n--- Teste Adicionar Estoque ---");
        p1.adicionarEstoque(5); // 10 + 5 = 15
        System.out.println("Estoque atual: " + p1.getQuantidade());
 
        System.out.println("\n--- Teste Venda Autorizada ---");
        boolean venda1 = p1.vender(7); 
        System.out.println("Venda realizada? " + venda1);
        System.out.println("Estoque atual: " + p1.getQuantidade());

        System.out.println("\n--- Teste Venda Recusada (Falta de Estoque) ---");
        boolean venda2 = p1.vender(10); 
        System.out.println("Venda realizada? " + venda2);
        System.out.println("Estoque atual permanece: " + p1.getQuantidade());
    }
}

class Produto {
  
    private String nome;
    private double preco;
    private int quantidade;

    public Produto(String nome, double preco, int quantidade) {
        this.nome = nome;
        if (preco >= 0) {
            this.preco = preco;
        } else {
            System.out.println("Aviso: Preço inicial inválido. Definido como 0.0.");
            this.preco = 0.0;
        }
        this.quantidade = quantidade >= 0 ? quantidade : 0;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        if (preco < 0) {
            System.out.println("Aviso: O preço não pode ser negativo! Operação rejeitada.");
        } else {
            this.preco = preco;
        }
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public void adicionarEstoque(int qtd) {
        if (qtd > 0) {
            this.quantidade += qtd;
        }
    }

    public boolean vender(int qtd) {
        if (qtd <= this.quantidade) {
            this.quantidade -= qtd;
            return true;
        } else {
            System.out.println("Aviso: Falha na venda. Quantidade solicitada indisponível em estoque.");
            return false;
        }
    }
}
