import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Jogador {
    private String nome;
    private int numero;
    private double altura;
    private char posicao;
    private double salario;
    private boolean lesionado;
    private int idade;

    public Jogador(String nome, int numero, double altura, char posicao, double salario, boolean lesionado, int idade) {
        this.nome = nome;
        this.numero = numero;
        this.altura = altura;
        this.posicao = posicao;
        this.salario = salario;
        this.lesionado = lesionado;
        this.idade = idade;
    }

    @Override
    public String toString() {
        return String.format("%s | %d | %c | %.2fm | %d anos | R$ %.2f | %s", 
                nome, numero, posicao, altura, idade, salario, (lesionado ? "Sim" : "Não"));
    }
}

public class Jogadores {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Jogador> elenco = new ArrayList<>();
        
        System.out.println("--- Cadastro de Jogadores ---");
        
        while (true) {
            System.out.print("Nome completo (ou 'sair' para encerrar): ");
            String nome = scanner.nextLine();
            if (nome.equalsIgnoreCase("sair")) {
                break;
            }
            
            System.out.print("Número da camisa: ");
            int numero = scanner.nextInt();
            
            System.out.print("Altura (em metros, ex: 1,85): ");
            double altura = scanner.nextDouble();
            
            System.out.print("Posição (G, Z, M, A): ");
            char posicao = scanner.next().toUpperCase().charAt(0);
            scanner.nextLine(); 
            
            System.out.print("Salário mensal: ");
            double salario = scanner.nextDouble();
            scanner.nextLine(); 
            
            System.out.print("Está lesionado? (true/false): ");
            boolean lesionado = scanner.nextBoolean();
            scanner.nextLine(); 
            
            System.out.print("Idade: ");
            int idade = scanner.nextInt();
            scanner.nextLine(); 
            
            Jogador jogador = new Jogador(nome, numero, altura, posicao, salario, lesionado, idade);
            elenco.add(jogador);
            System.out.println("Jogador cadastrado com sucesso!\n");
        }
        
        System.out.println("\n--- RELATÓRIO DO ELENCO ---");
        System.out.println("Nome | Nº | Pos | Altura | Idade | Salário | Lesionado");
        System.out.println("-------------------------------------------------------");
        for (Jogador j : elenco) {
            System.out.println(j);
        }
        
        scanner.close();
    }
}
