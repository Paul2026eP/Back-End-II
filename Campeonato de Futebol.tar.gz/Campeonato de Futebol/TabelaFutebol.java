import java.util.ArrayList;
import java.util.List;

public class TabelaFutebol {

    static class Time {
        String nome;
        int Jogos;
        int vitorias;
        int derrotas;
        int saldoGols;
        char categoria;
        boolean estaNaZonaClassificacao;

        public Time(String nome, int Jogos, int vitorias, int derrotas, int saldoGols, char categoria, boolean estaNaZonaClassificacao) {
            this.nome = nome;
            this.Jogos = Jogos;
            this.vitorias = vitorias;
            this.derrotas = derrotas;
            this.saldoGols = saldoGols;
            this.categoria = categoria;
            this.estaNaZonaClassificacao = estaNaZonaClassificacao;
        }


        public int calcularPontos() {
            return (this.vitorias * 3) + (this.derrotas * 0);
        }
    }

    public static void main(String[] args) {
  
        List<Time> times = new ArrayList<>();

        times.add(new Time("Time Real Madri       ", 10, 7, 3, 12, 'A', true));
        times.add(new Time("Time Barcelona        ", 10, 6, 4, 5 , 'A', true));
        times.add(new Time("Time Manchester United", 10, 5, 5, -2, 'B', false));
        times.add(new Time("Time Liverpool        ", 10, 4, 6, -4, 'B', false));
        times.add(new Time("Time Bayern de Munique", 10, 2, 8, -11, 'C', false));

    
        System.out.println("--- Tabela de Campeonato de Futebol ---");
        System.out.printf("%-25s | %-5s | %-8s | %-8s | %-5s | %-6s | %-9s | %-12s%n", 
                "Time", "Jogos", "Vitórias", "Derrotas", "Saldo de Gols", "Pontos", "Categoria", "Classificado");
        System.out.println("-----------------------------------------------------------------------------------------------------------");

        for (Time time : times) {
            System.out.printf("%-25s | %-5d | %-8d | %-8d | %-13d | %-6d | %-9c | %-12b%n",
                    time.nome,
                    time.Jogos,
                    time.vitorias,
                    time.derrotas,
                    time.saldoGols,
                    time.calcularPontos(),
                    time.categoria,
                    time.estaNaZonaClassificacao);
        }
    }
}
