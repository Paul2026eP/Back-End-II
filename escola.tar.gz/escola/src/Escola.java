import java.util.ArrayList;
import java.util.List;

// ==========================================
// CLASSES DA ESTRUTURA (Sem modificador public)
// ==========================================

abstract class Disciplina {
    private String codigo;
    private String nome;

    public Disciplina(String codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
    }

    @Override
    public String toString() {
        return this.nome + " (" + this.codigo + ")";
    }
}

class DisciplinaObrigatoria extends Disciplina {
    private int periodo;

    public DisciplinaObrigatoria(String codigo, String nome, int periodo) {
        super(codigo, nome);
        this.periodo = periodo;
    }
}

class DisciplinaOptativa extends Disciplina {
    private String perfil;

    public DisciplinaOptativa(String codigo, String nome, String perfil) {
        super(codigo, nome);
        this.perfil = perfil;
    }
}

abstract class Professor {
    private String nome;
    private String cpf;
    private String registro;

    public Professor(String nome, String cpf, String registro) {
        this.nome = nome;
        this.cpf = cpf;
        this.registro = registro;
    }

    @Override
    public String toString() {
        return this.nome;
    }
}

class ProfessorEfetivo extends Professor {
    private double salario;

    public ProfessorEfetivo(String nome, String cpf, String registro, double salario) {
        super(nome, cpf, registro);
        this.salario = salario;
    }
}

class ProfessorSubstituto extends Professor {
    private int horas;

    public ProfessorSubstituto(String nome, String cpf, String registro, int horas) {
        super(nome, cpf, registro);
        this.horas = horas;
    }
}

abstract class Aluno {
    private String nome;
    private String cpf;
    private String matricula;

    public Aluno(String nome, String cpf, String matricula) {
        this.nome = nome;
        this.cpf = cpf;
        this.matricula = matricula;
    }

    @Override
    public String toString() {
        return this.nome + " [Matrícula: " + this.matricula + "]";
    }
}

class AlunoGraduacao extends Aluno {
    private String curso;

    public AlunoGraduacao(String nome, String cpf, String matricula, String curso) {
        super(nome, cpf, matricula);
        this.curso = curso;
    }
}

class AlunoPosGraduacao extends Aluno {
    private String linhaPesquisa;

    public AlunoPosGraduacao(String nome, String cpf, String matricula, String linhaPesquisa) {
        super(nome, cpf, matricula);
        this.linhaPesquisa = linhaPesquisa;
    }
}

abstract class Turma {
    private String codigo;
    private Disciplina disciplina;
    private Professor professor;
    private List<Aluno> alunos;

    public Turma(String codigo, Disciplina disciplina, Professor professor) {
        this.codigo = codigo;
        this.disciplina = disciplina;
        this.professor = professor;
        this.alunos = new ArrayList<>();
    }

    public void adicionarAluno(Aluno aluno) {
        this.alunos.add(aluno);
    }

    public List<Aluno> getAlunos() {
        return this.alunos;
    }

    @Override
    public String toString() {
        return "Turma: " + this.codigo + " | Disciplina: " + this.disciplina + " | Professor: " + this.professor;
    }
}

class TurmaPresencial extends Turma {
    private String sala;

    public TurmaPresencial(String codigo, Disciplina disciplina, Professor professor, String sala) {
        super(codigo, disciplina, professor);
        this.sala = sala;
    }

    @Override
    public String toString() {
        return super.toString() + " | Sala: " + this.sala;
    }
}

class TurmaEAD extends Turma {
    private String urlAmbiente;

    public TurmaEAD(String codigo, Disciplina disciplina, Professor professor, String urlAmbiente) {
        super(codigo, disciplina, professor);
        this.urlAmbiente = urlAmbiente;
    }

    @Override
    public String toString() {
        return super.toString() + " | Link: " + this.urlAmbiente;
    }
}

// ==========================================
// CLASSE PRINCIPAL EXECUTÁVEL (Única Public)
// ==========================================

public class Escola {
    public static void main(String[] args) {
        System.out.println("=== SISTEMA DE PROJETO ESCOLA ===");

        // Criando Disciplinas
        DisciplinaObrigatoria Codigo = new DisciplinaObrigatoria("MAT101", "Back-End1", 3);
        DisciplinaOptativa IA = new DisciplinaOptativa("CC502", "Inteligência Artificial na Prática", "Tecnologia");
        DisciplinaOptativa AD = new DisciplinaOptativa("CC502", "Analista de Dados", "Tecnologia");

        // Criando Professores
        Professor profCarlos = new ProfessorEfetivo("Carlos Silva", "111.222.333-44", "RF8832", 7500.0);
        Professor profAna = new ProfessorSubstituto("Ana Oliveira", "555.666.777-88", "RF1102", 6);
        Professor profMarcio = new ProfessorEfetivo("Marcio Costa Junior", "555.666.666-88", "RF1109", 2500.0);

        // Criando Alunos
        Aluno alunoLucas = new AlunoGraduacao("Lucas Mendes", "123.456.789-00", "2024001", "Engenharia");
        Aluno alunaBeatriz = new AlunoPosGraduacao("Beatriz Souza", "987.654.321-99", "2024002", "Deep Learning");
        Aluno alunoLuciano = new AlunoGraduacao("Luciano Leite", "123.459.799-10", "2024005", "Desenvolvimento de Sistemas");

        // Criando Turmas
        TurmaPresencial turmaEng = new TurmaPresencial("T-Subsequente2026", Codigo, profCarlos, "Bloco A - Sala 202");
        TurmaEAD turmaIA = new TurmaEAD("T-IntergradaIA-2026", IA, profAna, "https://escola.edu");
        TurmaPresencial turmaDS = new TurmaPresencial("T-Concomitante2026", AD, profMarcio, "Bloco A - Sala 203");

        // Matriculando Alunos
        turmaEng.adicionarAluno(alunoLucas);
        turmaDS.adicionarAluno(alunaBeatriz);
        turmaDS.adicionarAluno(alunoLuciano);
        turmaIA.adicionarAluno(alunaBeatriz);
        turmaIA.adicionarAluno(alunoLucas);
        turmaIA.adicionarAluno(alunoLuciano);

        // Exibindo Dados
        System.out.println("\n--- Detalhes das Turmas ---");

        System.out.println(turmaEng);
        System.out.println(" Alunos matriculados:");
        for (Aluno a : turmaEng.getAlunos()) {
            System.out.println("  -> " + a);
        }

        System.out.println("\n" + turmaDS);
        System.out.println(" Alunos matriculados:");
        for (Aluno b : turmaDS.getAlunos()) {
            System.out.println("  -> " + b);
        }

        System.out.println("\n" + turmaIA);
        System.out.println(" Alunos matriculados:");
        for (Aluno c : turmaIA.getAlunos()) {
            System.out.println("  -> " + c);
        }
    }
}
