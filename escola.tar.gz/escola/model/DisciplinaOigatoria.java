package model;

public class DisciplinaOigatoria extends Disciplina {
    private int periodoRecomendado;

    public DisciplinaOigatoria(String codigo, String nome, int periodoRecomendado) {
        super(codigo, nome);
        this.periodoRecomendado = periodoRecomendado;
    }

    public int getPeriodoRecomendado() { return periodoRecomendado; }
    public void setPeriodoRecomendado(int periodoRecomendado) { this.periodoRecomendado = periodoRecomendado; }

    @Override
    public String toString() {
        return super.toString() + " (Obrigatória - " + periodoRecomendado + "º Período)";
    }
}