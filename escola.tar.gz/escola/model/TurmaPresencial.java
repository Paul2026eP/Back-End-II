package model;

public class TurmaPresencial extends Turma {
    private String sala;

    public TurmaPresencial(String identificador, Disciplina disciplina, Professor professor, String sala) {
        super(identificador, disciplina, professor);
        this.sala = sala;
    }

    public String getSala() { return sala; }
    public void setSala(String sala) { this.sala = sala; }

    @Override
    public String toString() {
        return super.toString() + " [Presencial - Sala: " + sala + "]";
    }
}