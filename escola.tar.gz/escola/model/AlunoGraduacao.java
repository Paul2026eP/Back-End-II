package model;

public class AlunoGraduacao extends Aluno {
    private String curso;

    public AlunoGraduacao(String nome, String cpf, String matricula, String curso) {
        super(nome, cpf, matricula);
        this.curso = curso;
    }

    public String getCurso() { return curso; }
    public void setCurso(String curso) { this.curso = curso; }

    @Override
    public String toString() {
        return super.toString() + " (Graduação), Curso: " + curso;
    }
}