package model;

import java.util.ArrayList;
import java.util.List;

public class Turma {
    private String identificador;
    private Disciplina disciplina;
    private Professor professor;
    private List<Aluno> alunos;

    public Turma(String identificador, Disciplina disciplina, Professor professor) {
        this.identificador = identificador;
        this.disciplina = disciplina;
        this.professor = professor;
        this.alunos = new ArrayList<>();
    }

    public String getIdentificador() { return identificador; }
    public Disciplina getDisciplina() { return disciplina; }
    public Professor getProfessor() { return professor; }
    public List<Aluno> getAlunos() { return alunos; }

    public void adicionarAluno(Aluno aluno) {
        this.alunos.add(aluno);
    }

    @Override
    public String toString() {
        return "Turma: " + identificador + " | Disciplina: " + disciplina.getNome() + " | Professor: " + professor.getNome() + " | Alunos: " + alunos.size();
    }
}