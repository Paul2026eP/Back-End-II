package model;

public class ProfessorEfetivo extends Professor {
    private double salarioBase;

    public ProfessorEfetivo(String nome, String cpf, String registroFuncional, double salarioBase) {
        super(nome, cpf, registroFuncional);
        this.salarioBase = salarioBase;
    }

    public double getSalarioBase() { return salarioBase; }
    public void setSalarioBase(double salarioBase) { this.salarioBase = salarioBase; }

    @Override
    public String toString() {
        return super.toString() + " (Efetivo), Salário: R$ " + salarioBase;
    }
}