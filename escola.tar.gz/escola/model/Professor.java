package model;

public class Professor extends Pessoa {
    private String registroFuncional;

    public Professor(String nome, String cpf, String registroFuncional) {
        super(nome, cpf);
        this.registroFuncional = registroFuncional;
    }

    public String getRegistroFuncional() { return registroFuncional; }
    public void setRegistroFuncional(String registroFuncional) { this.registroFuncional = registroFuncional; }

    @Override
    public String toString() {
        return super.toString() + ", RF: " + registroFuncional;
    }
}