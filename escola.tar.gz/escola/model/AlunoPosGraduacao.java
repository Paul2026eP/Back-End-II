package model;

public class AlunoPosGraduacao extends Aluno {
    private String linhaPesquisa;

    public AlunoPosGraduacao(String nome, String cpf, String matricula, String linhaPesquisa) {
        super(nome, cpf, matricula);
        this.linhaPesquisa = linhaPesquisa;
    }

    public String getLinhaPesquisa() { return linhaPesquisa; }
    public void setLinhaPesquisa(String linhaPesquisa) { this.linhaPesquisa = linhaPesquisa; }

    @Override
    public String toString() {
        return super.toString() + " (Pós-Graduação), Pesquisa: " + linhaPesquisa;
    }
}