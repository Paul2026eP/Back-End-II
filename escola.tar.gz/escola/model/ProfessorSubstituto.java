package model;

public class ProfessorSubstituto extends Professor {
    private int mesesContrato;

    public ProfessorSubstituto(String nome, String cpf, String registroFuncional, int mesesContrato) {
        super(nome, cpf, registroFuncional);
        this.mesesContrato = mesesContrato;
    }

    public int getMesesContrato() { return mesesContrato; }
    public void setMesesContrato(int mesesContrato) { this.mesesContrato = mesesContrato; }

    @Override
    public String toString() {
        return super.toString() + " (Substituto), Contrato: " + mesesContrato + " meses";
    }
}