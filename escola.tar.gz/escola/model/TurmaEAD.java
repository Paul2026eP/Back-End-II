package model;

public class TurmaEAD extends Turma {
    private String urlAmbienteVirtual;

    public TurmaEAD(String identificador, Disciplina disciplina, Professor professor, String urlAmbienteVirtual) {
        super(identificador, disciplina, professor);
        this.urlAmbienteVirtual = urlAmbienteVirtual;
    }

    public String getUrlAmbienteVirtual() { return urlAmbienteVirtual; }
    public void setUrlAmbienteVirtual(String urlAmbienteVirtual) { this.urlAmbienteVirtual = urlAmbienteVirtual; }

    @Override
    public String toString() {
        return super.toString() + " [EAD - Link: " + urlAmbienteVirtual + "]";
    }
}