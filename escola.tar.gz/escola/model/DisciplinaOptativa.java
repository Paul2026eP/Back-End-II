package model;

public class DisciplinaOptativa extends Disciplina {
    private String areaInteresse;

    public DisciplinaOptativa(String codigo, String nome, String areaInteresse) {
        super(codigo, nome);
        this.areaInteresse = areaInteresse;
    }

    public String getAreaInteresse() { return areaInteresse; }
    public void setAreaInteresse(String areaInteresse) { this.areaInteresse = areaInteresse; }

    @Override
    public String toString() {
        return super.toString() + " (Optativa - Área: " + areaInteresse + ")";
    }
}