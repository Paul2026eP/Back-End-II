package com.mercadinho.vendas.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity // [Tópico 2 - Spring Data JPA] Mapeia esta classe para uma tabela no banco relacional (PostgreSQL/MySQL)
@Table(name = "tb_produtos") // [Tópico 3 - SQL] Define o nome exato da tabela controlada via Flyway/Liquibase
public class Produto {

    @Id // [Tópico 3 - SQL] Chave primária (Primary Key) da tabela
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // [Tópico 1 - Encapsulamento] Atributo privado com tipo Wrapper (permite nulo antes de salvar)

    private String nome; // [Tópico 1 - Java Core] Texto imutável (String pool)
    private BigDecimal preco; // [Tópico 1 - Java Core] Tipo exato para dinheiro (evita erros de arredondamento do double/float)

    // Construtores, Getters e Setters omitidos para brevidade (ou gerados via Lombok)
    public Produto() {}
    public Produto(String nome, BigDecimal preco) {
        this.nome = nome;
        this.preco = preco;
    }
    public String getNome() { return nome; }
    public BigDecimal getPreco() { return preco; }
}
