# --- INÍCIO DO PROJETO: CONTROLE DE VENDAS SIMPLES ---

nome_loja = "Mercadinho Central"  # Armazena o nome da loja (texto/string)
taxa_desconto = 0.10              # Define 10% de desconto para compras altas (decimal/float)
valor_minimo_desconto = 100.00    # Valor mínimo para ganhar o desconto (decimal/float)
total_compra = 0.0                # Acumulador que soma o valor dos produtos (inicia zerado)
quantidade_itens = 0              # Contador de quantos produtos foram passados (inteiro/int)

print(f"Bem-vindo ao sistema do {nome_loja}!")

# Laço de repetição para registrar vários produtos
while True:
    nome_produto = input("\nDigite o nome do produto (ou 'sair' para finalizar): ")  # Guarda o nome do item atual
    
    if nome_produto.lower() == 'sair':
        break  # Encerra o loop se o usuário digitar 'sair'
        
    preco_produto = float(input(f"Digite o preço de {nome_produto}: R$ "))  # Guarda o valor unitário do item
    
    total_compra += preco_produto   # Soma o preço atual ao total acumulado
    quantidade_itens += 1           # Adiciona +1 na contagem de itens

# Verificação de desconto após encerrar a passagem dos produtos
if total_compra >= valor_minimo_desconto:
    valor_desconto = total_compra * taxa_desconto  # Calcula quanto será abatido do total
    valor_final = total_compra - valor_desconto    # Calcula o valor final já com o desconto
    teve_desconto = True                           # Flag booleana (Verdadeiro/Falso) indicando que houve desconto
else:
    valor_desconto = 0.0           # Define desconto zero caso não atinja o mínimo
    valor_final = total_compra     # O valor final permanece igual ao total bruto
    teve_desconto = False          # Flag indicando que não houve desconto

# --- RESUMO DA COMPRA ---
print("\n" + "="*30)
print(f"Itens passados: {quantidade_itens}")
print(f"Subtotal: R$ {total_compra:.2f}")

if teve_desconto:
    print(f"Desconto aplicado (10%): -R$ {valor_desconto:.2f}")

print(f"Total a pagar: R$ {valor_final:.2f}")
print("="*30)
