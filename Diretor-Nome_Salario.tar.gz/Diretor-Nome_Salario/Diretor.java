
import java.util.Locale;

class Funcionario {
    protected String nome;
    protected double salario;

    public Funcionario(String nome, double salario) {
        this.nome = nome;
        this.salario = salario;
    }

    public void exibir() {
        System.out.printf(Locale.US, "Funcionário: %s recebe R$  %.2f%n", nome, salario);
    }
}

public class Diretor extends Funcionario {
    private double bonusExtra;

    public Diretor(String nome, double salario, double bonusExtra) {
        super(nome, salario);
        this.bonusExtra = bonusExtra;
    }

    @Override 
    public void exibir() {
        System.out.printf(Locale.of("pt", "BR"), "Diretor: %s recebe R$ %.2f%n", nome, (salario + bonusExtra));
        

    }

    public static void main(String[] args) {
        Diretor diretorMaster = new Diretor("Aguiar Silva", 100000.00, 35000.00);
        Diretor diretor1 = new Diretor("Carlos Silva", 40000.00, 10000.00);
        Diretor diretor2 = new Diretor("Marcos Silva", 35000.00, 8000.00);
        Diretor diretor3 = new Diretor("Luana Silva", 38000.00, 7000.00);
        
        System.out.println();
        diretorMaster.exibir();
        diretor1.exibir();
        diretor2.exibir();
        diretor3.exibir();
        System.out.println();
    }
}

