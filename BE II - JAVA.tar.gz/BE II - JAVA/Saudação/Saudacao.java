import java.util.Scanner; // importa a classe do teclado
public class Saudacao {
public static void main(String[] args) {
Scanner teclado = new Scanner(System.in);
System.out.print("Qual é o seu nome? ");
String nome = teclado.nextLine(); // lê uma linha

System.out.print("Qual a sua idade? ");
int idade = teclado.nextInt(); // lê um inteiro
System.out.println(nome + " tem " + idade + " anos.");
teclado.close();
}
}