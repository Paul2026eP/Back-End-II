/*public class Conta {
    public static void main(String[] args) {
    String titular = "Maria";
    double saldo = 1000.00;
    double saque = 250.50;
    saldo = saldo - saque; // atualiza o saldo
System.out.println("Titular: " + titular);
System.out.println("Saldo após o saque: R$ " + saldo); //Saida com resultado sem uma casa decimal
}
}*/

//--------------------------------------------------------------------------------------------------

/*import java.text.DecimalFormat; //Importação para 2 casas após a virgula

public class Conta {
    public static void main(String[] args) {
        String titular = "Maria";
        double saldo = 1000.00;
        double saque = 250.50;

        saldo = saldo - saque; // atualiza o saldo

        DecimalFormat df = new DecimalFormat("0.00");

        System.out.println("Titular: " + titular);
        System.out.println("Saldo após o saque: R$ " + df.format(saldo));
    }
}*/

//--------------------------------------------------------------------------------------------------

/*public class Conta {
    public static void main(String[] args) {
        String titular = "Maria";
        double saldo = 1000.00;
        double saque = 250.50;

        saldo = saldo - saque; // atualiza o saldo

        System.out.println("Titular: " + titular);
        System.out.printf("Saldo após o saque: R$ %.2f%n", saldo);
    }
}*/

//--------------------------------------------------------------------------------------------------

/*public class Conta {
    public static void main(String[] args) {
        String titular = "Maria";
        double saldo = 1000.00;
        double saque = 250.50;

        saldo = saldo - saque; // atualiza o saldo

        System.out.println("Titular: " + titular);
        System.out.println("Saldo após o saque: R$ " + String.format("%.2f", saldo));
    }
}*/

//--------------------------------------------------------------------------------------------------

/*public class Conta {
    public static void main(String[] args) {
    String titular = "Maria";
    double saldo = 1000.00;
    double saque = 250.50;
saldo = saldo - saque; // 1000.00 - 250.50 = 749.50
System.out.println("Saldo após o saque: R$ " + saldo); //Saida com resultado sem uma casa decimal
    }
}*/
    


