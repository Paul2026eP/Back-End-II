/*public class Aprovacao {
public static void main(String[] args) {
double nota = 7.5; // nota fixa

if (nota >= 6) {
System.out.println("Aprovado!");
} else {
System.out.println("Reprovado.");
}
}
}*/

//-------------------------------------------------------------------------------

/*import java.util.Scanner;

public class Aprovacao {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Qual a sua nota? ");
        double nota = sc.nextDouble(); //nota digitada pelo o aluno, e escaneada pelo sistema.

        if (nota >= 6) {
            System.out.println("Aprovado!");
        } else {
            System.out.println("Reprovado.");
        }

        sc.close();
    }
}*/

//-------------------------------------------------------------------------------

import java.util.Scanner;

public class Aprovacao {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite nota da primeira atividade: ");
        double nota1 = sc.nextDouble();

        System.out.print("Digite a nota do trabalho em sala: ");
        double nota2 = sc.nextDouble();

        System.out.print("Digite a nota da prova final: ");
        double nota3 = sc.nextDouble();

        // Definindo os pesos (última nota com maior peso)
       // Definindo os pesos (última nota com maior peso)
        double peso1 = 0.20; // 20%
        double peso2 = 0.30; // 30%
        double peso3 = 0.50; // 50%


        // Média ponderada
        double media = (nota1 * peso1 + nota2 * peso2 + nota3 * peso3) / (peso1 + peso2 + peso3);

        System.out.println("Sua média foi: " + media);

        if (media >= 6) {
            System.out.println("Aprovado!");
        } else {
            System.out.println("Reprovado.");
        }

        sc.close();
    }
}

