import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;

public class ServidorBuscaCSV {
    public static void main(String[] args) throws IOException {
        // Inicializa o servidor web na porta 8080
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        server.createContext("/buscar", new HandlerBusca());
        server.setExecutor(null); 
        System.out.println("Servidor Java Ativo! Aguardando requisições na porta 8080...");
        server.start();
    }

    static class HandlerBusca implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            // Permite que o arquivo HTML (mesmo aberto localmente) acesse o Java sem erros de CORS
            exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
            exchange.getResponseHeaders().add("Content-Type", "application/json; charset=UTF-8");

            // Extrai o parâmetro enviado pelo HTML (?produto=nome)
            String query = exchange.getRequestURI().getQuery();
            String termoBusca = "";
            if (query != null && query.contains("produto=")) {
                termoBusca = query.split("produto=")[1].toLowerCase();
            }

            StringBuilder jsonResultado = new StringBuilder("[");
            String caminhoArquivo = "dados_vendas.csv";

            try (BufferedReader br = new BufferedReader(new FileReader(caminhoArquivo))) {
                String linha = br.readLine(); // Pula o cabeçalho do CSV
                boolean primeiroItem = true;

                while ((linha = br.readLine()) != null) {
                    String[] colunas = linha.split(",");
                    if (colunas.length >= 5) {
                        String nomeProduto = colunas[1];

                        // Filtra se o produto contém o termo digitado no HTML
                        if (nomeProduto.toLowerCase().contains(termoBusca)) {
                            if (!primeiroItem) jsonResultado.append(",");
                            
                            // Monta a string no formato JSON padrão aceito pelo JavaScript
                            jsonResultado.append(String.format(
                                "{\"Data\":\"%s\",\"Produto\":\"%s\",\"Quantidade\":\"%s\",\"ValorUnitario\":\"%s\",\"Total\":\"%s\"}",
                                colunas[0], colunas[1], colunas[2], colunas[3], colunas[4]
                            ));
                            primeiroItem = false;
                        }
                    }
                }
            } catch (IOException e) {
                System.err.println("Erro ao ler o CSV: " + e.getMessage());
            }

            jsonResultado.append("]");
            byte[] responseBytes = jsonResultado.toString().getBytes("UTF-8");
            
            // Envia a resposta de volta para o Front-end
            exchange.sendResponseHeaders(200, responseBytes.length);
            OutputStream os = exchange.getResponseBody();
            os.write(responseBytes);
            os.close();
        }
    }
}
