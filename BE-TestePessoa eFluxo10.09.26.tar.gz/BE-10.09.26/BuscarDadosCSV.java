import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class BuscarDadosCSV {
    public static void main(String[] args) {
        String caminhoArquivo = "dados_vendas.csv";
        
        // Termo que você quer encontrar (pode mudar para "Notebook", "Monitor", etc.)
        String termoBusca = "Teclado"; 
        
        System.out.println("Iniciando busca pelo produto: " + termoBusca + "...\n");

        // O BufferedReader lê o arquivo linha por linha de forma eficiente
        try (BufferedReader br = new BufferedReader(new FileReader(caminhoArquivo))) {
            String linha;
            boolean encontrou = false;

            // Ler a primeira linha (cabeçalho) para sabermos a estrutura
            String cabecalho = br.readLine();
            System.out.println("Resultado da busca:");
            System.out.println("-------------------------------------------------------------");
            System.out.println(cabecalho.replace(",", " | ")); // Formata o cabeçalho na tela
            System.out.println("-------------------------------------------------------------");

            // Loop para ler o restante das linhas do arquivo CSV
            while ((linha = br.readLine()) != null) {
                
                // O método split(",") divide a linha em um array de textos usando a vírgula
                String[] colunas = linha.split(",");
                
                // A coluna [1] é onde fica o nome do Produto (Data=0, Produto=1, Quantidade=2...)
                String nomeProduto = colunas[1];

                // contains() ignora se está maiúsculo ou minúsculo se usarmos toLowerCase()
                if (nomeProduto.toLowerCase().contains(termoBusca.toLowerCase())) {
                    // Exibe a linha formatada trocando vírgula por barra
                    System.out.println(linha.replace(",", " | "));
                    encontrou = true;
                }
            }

            System.out.println("-------------------------------------------------------------");
            if (!encontrou) {
                System.out.println("Nenhum produto com o termo '" + termoBusca + "' foi encontrado.");
            }

        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo CSV: " + e.getMessage());
        }
    }
}
