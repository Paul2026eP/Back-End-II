class Pessoa {
    String nome;
    int idade;

    // Metodo para calcular a idade em meses
    public int calcularIdadeEmMeses() {
        return idade * 12; // Multiplica a idade em anos por 12
    }
}

public class TestePessoa { 
    public static void main(String [] args){
        
       
        Pessoa maria = new Pessoa(); 
        
        maria.nome = "Maria";
        maria.idade = 38;

        int meses = maria.calcularIdadeEmMeses();
        
       
        System.out.println(maria.nome + " tem " + meses + " meses de vida.");
    }
}
