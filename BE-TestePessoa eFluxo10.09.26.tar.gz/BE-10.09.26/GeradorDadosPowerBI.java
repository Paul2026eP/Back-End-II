import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

public class GeradorDadosPowerBI {
    public static void main(String[] args) {
        // Caminho do arquivo que o Power BI vai ler
        String caminhoArquivo = "dados_vendas.csv";

        System.out.println("Iniciando fluxo de dados para o Power BI...");

        try (FileWriter fw = new FileWriter(caminhoArquivo);
             PrintWriter pw = new PrintWriter(fw)) {

            // Escreve o cabeçalho do CSV (Colunas)
            pw.println("Data,Produto,Quantidade,ValorUnitario,Total");

            // Simula o fluxo gerando linhas de dados
            pw.println(LocalDate.now().minusDays(2) + ",Notebook,2,4500.00,9000.00");
            pw.println(LocalDate.now().minusDays(1) + ",Teclado Mecanico,5,350.00,1750.00");
            pw.println(LocalDate.now() + ",Monitor 4K,1,2200.00,2200.00");
            pw.println(LocalDate.now() + ",Mouse Gamer,10,150.00,1500.00");

            System.out.println("Fluxo finalizado! Arquivo '" + caminhoArquivo + "' gerado com sucesso.");

        } catch (IOException e) {
            System.err.println("Erro ao gerar o fluxo de dados: " + e.getMessage());
        }
    }
}
