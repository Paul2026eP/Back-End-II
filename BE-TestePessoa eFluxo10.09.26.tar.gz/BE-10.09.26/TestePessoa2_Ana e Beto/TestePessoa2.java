class Pessoa {
    String nome;
    int idade;

    // Metodo para calcular a idade em meses
    public int calcularIdadeEmMeses() {
        return idade * 12; // Multiplica a idade em anos por 12
    }
}

public class TestePessoa2 { 
    public static void main(String [] args){
        
        // Observar: 'ana' em minúsculo para manter o padrão
        Pessoa ana = new Pessoa(); 
        ana.nome = "Ana";
        ana.idade = 22;
       
        int mesesAna = ana.calcularIdadeEmMeses(); 

        //Lembrar minisculo
        Pessoa beto = new Pessoa(); 
        beto.nome = "Beto"; 
        beto.idade = 30;

        int mesesBeto = beto.calcularIdadeEmMeses(); 
        
       
        System.out.println(ana.nome + " tem " + mesesAna + " meses de vida.");
        System.out.println(beto.nome + " tem " + mesesBeto + " meses de vida.");
        System.out.println("Objetos são independentes entre si.");
    }
}
