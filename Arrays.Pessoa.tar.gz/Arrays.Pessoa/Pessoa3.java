public class Pessoa3 { 
    String nome;
    int idade;
    
    Pessoa3(String nome, int idade) { 
        this.nome = nome;
        this.idade = idade;
    }

    @Override 
    public String toString() { 
        return nome + " (" + idade + " anos)"; 
    }

    public static void main(String[] args) { 
        Pessoa3[] pessoas = {
            new Pessoa3("Ana", 25),
            new Pessoa3("Bruno", 30),
            new Pessoa3("Carla", 22)
        };

        for(Pessoa3 p: pessoas) { 
            System.out.println(p); 
        } 
        
        System.out.println("Tamanho: " + pessoas.length); 
    } 
}
