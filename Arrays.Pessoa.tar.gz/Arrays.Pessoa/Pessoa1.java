public class Pessoa1 {
    String nome;
    int idade;

    Pessoa1 (String nome, int idade) {
        this.nome = nome;
        this.idade = idade; 
    }

    @Override 
    public String toString() {
        return nome + " (" + idade + " anos)";
    }    

    
    public static void main(String[] args) {
        Pessoa1 p = new Pessoa1("Ana", 25);
        System.out.println(p); 
    }
}
