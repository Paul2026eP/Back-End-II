import java.util.Arrays; //Usando java util Arrays

public class Pessoa {
    String nome;
    int idade;

    Pessoa (String nome, int idade) {
        this.nome = nome;
        this.idade = idade; 
    }

    @Override 
    public String toString() {
        return nome + " (" + idade + " anos)";
    }    

    public static void main(String[] args) {
       
        Pessoa[] listaDePessoas = new Pessoa[6];
        listaDePessoas[0] = new Pessoa("Ana", 25);
        listaDePessoas[1] = new Pessoa("Carlos", 30);
        listaDePessoas[2] = new Pessoa("Lucas", 35);
        listaDePessoas[3] = new Pessoa("Maycon", 32);
        listaDePessoas[4] = new Pessoa("John", 28);
        listaDePessoas[5] = new Pessoa("Leila", 27);

        System.out.println(Arrays.toString(listaDePessoas)); 
    }
}
