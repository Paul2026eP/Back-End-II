public class Pessoa2 { 
    String nome;
    int idade;
    
    Pessoa2(String nome, int idade) { 
        this.nome = nome;
        this.idade = idade;
    }

    @Override 
    public String toString() { 
        return nome + " (" + idade + " anos)"; 
    }

    public static void main(String[] args) { 
        Pessoa2[] pessoas = new Pessoa2[3];
        
        pessoas[0] = new Pessoa2("Ana", 25); 
        pessoas[1] = new Pessoa2("Bruno", 30); 
        pessoas[2] = new Pessoa2("Carla", 22); 

        for(Pessoa2 p: pessoas) { 
            System.out.println(p); 
        } 
        
        System.out.println("Tamanho: " + pessoas.length); 
    } 
}
