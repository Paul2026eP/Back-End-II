import java.util.*;

public class Strings {

        public static void main(String[] args) {

                // O programa começa aqui
                String nome = "João da Silva";
                // Índice: 0 1 2 3 4 5 6 7 8 9 10 11 12
                // Texto: J o ã o d a S i l v a

                System.out.println("Tamanho: " + nome.length());
                // "João da Silva"
                // J o ã o _ d a _ S i l v a
                // 1 2 3 4 5 6 7 8 9 ...
                // Saída:
                // Tamanho: 13

                System.out.println("Maiúsculas: "
                                + nome.toUpperCase());
                // Saída:
                // Maiúsculas: JOÃO DA SILVA

                String maiuscula = nome.toUpperCase();
                System.out.println(nome); // João da Silva
                System.out.println(maiuscula); // JOÃO DA SILVA

                System.out.println("Começa com Jo? "
                                + nome.startsWith("Jo"));
                // Saída:
                // Começa com Jo? true
                nome.startsWith("João"); // true
                nome.startsWith("Silva"); // false
                nome.startsWith("jo"); // false

                System.out.println("Contém Silva? "
                                + nome.contains("Silva"));
                // Saída:
                // Contém Silva? true
                nome.contains("Silva"); // true
                nome.contains("silva"); // false
                nome.contains("da"); // true

                // Exemplo: pega os primeiros 7 caracteres e depois corta a partir do 5
                String sub = nome.substring(0, 1) + "." + nome.substring(4, 6) + "." + nome.substring(7, 9) + ".";
                System.out.println("Iniciais: " + sub);
                // Índice: 0 1 2 3 4 5 6 7 8 9 10 11 12
                // Texto: J o ã o d a S i l v a
                // ↑ ↑
                // início=0 meio=5 fim= 9
                // Saída:
                // Pedacinho: da S

                // OBS: substring(0, 5, 9);
                // Posição 0 → "J"
                // Posição 6 → "d"
                // Posição 7 → "a"
                // Posição 8 → " "
                // Resultado: " da "
                // Regra:
                // início é incluído
                // fim NÃO é incluído

                System.out.println("Trocou: " // replace refaz o estado
                                + nome.replace("João", "José"));
                // Antes: João da Silva
                // Depois: José da Silva
                // Saída:
                // Trocou: José da Silva

                // "RESUMO OPERACIONAL DA APLICAÇÕES"
                // length() -> tamanho - conta os caracteres.
                // toUpperCase() -> MAIÚSCULAS - transforma em maiúsculas.
                // startsWith() -> começa com? - verifica o início.
                // contains() -> contém? - verifica se contém.
                // substring(a,b) -> recorte - recorta parte do texto.
                // replace() -> substituição - substitui um trecho.
                

                String frase = "Aprender Java é divertido";

                System.out.println();
                System.out.println(frase.length());
                System.out.println(frase.toUpperCase());
                System.out.println(frase.startsWith("Aprender"));
                System.out.println(frase.contains("Java"));
                System.out.println(frase.substring(9, 13));
                System.out.println(frase.replace("divertido", "legal"));
                
                //String texto = "Java";
                // Erro: índice fora dos limites
                //String errado = texto.substring(0, 10);
                // Correto:
                //String certo = texto.substring(0, 4);
        }

}