import java.util.Scanner;

public class SistemaBancario {

    // Atributos privados (protegidos por encapsulamento)
    private String nomeCompleto;
    private String cpf;
    private double saldo;

    // Construtor para cadastrar o cliente
    public SistemaBancario(String nomeCompleto, String cpf, double saldo) {
        this.nomeCompleto = nomeCompleto;
        this.cpf = cpf;
        this.saldo = saldo;
    }

    // Nível 1: OPERADOR (Nome resumido usando replace)
    public String getDadosOperador() {
        String[] partes = nomeCompleto.split(" ");
        String primeiroNome = partes[0];
        String inicial = partes[partes.length - 1].substring(0, 1) + ".";
        String nomeResumido = nomeCompleto.replace(nomeCompleto, primeiroNome + " " + inicial);

        return "Cliente: " + nomeResumido;
    }

    // Nível 2: GERÊNCIA (Nome completo + Saldo)
    public String getDadosGerencia() {
        return "Cliente: " + nomeCompleto + " | Saldo: R$ " + saldo;
    }

    // Nível 3: DIRETOR (Dados pessoais completos)
    public String getDadosDiretor() {
        return "Cliente: " + nomeCompleto + " | CPF: " + cpf + " | Saldo: R$ " + saldo;
    }

    public static void main(String[] args) {
        // --- PARTE 1: Métodos de String ---
        String frase = "Aprender Java no sistema";
        System.out.println("Tamanho: " + frase.length());
        System.out.println("Maiúsculo: " + frase.toUpperCase());
        System.out.println("Começa com 'Aprender'? " + frase.startsWith("Aprender"));
        System.out.println("Contém 'Java'? " + frase.contains("Java"));
        System.out.println("Substring (9, 13): " + frase.substring(9, 13));

        // --- PARTE 2: Cadastro dos 3 Clientes ---
        SistemaBancario[] clientes = {
            new SistemaBancario("Carlos Eduardo Silva", "111.222.333-44", 1500.50),
            new SistemaBancario("Mariana Alves Souza", "555.666.777-88", 8200.00),
            new SistemaBancario("Roberto Gomes Pereira", "999.000.111-22", 25400.75)
        };

        // --- PARTE 3: Loop de Autenticação e Níveis de Acesso ---
        Scanner scanner = new Scanner(System.in);
        int perfil = -1;

        while (perfil != 0) {
            System.out.println("\n=== LOGIN NO SISTEMA BANCÁRIO ===");
            System.out.println("1 - Operador | 2 - Gerência | 3 - Diretor | 0 - Sair");
            System.out.print("Escolha uma opção: ");
            perfil = scanner.nextInt();

            // Encerra o loop se o usuário digitar 0
            if (perfil == 0) {
                System.out.println("Encerrando o sistema. Até logo!");
                break;
            }

            // Verifica se a opção está entre 1 e 3 antes de pedir a senha
            if (perfil < 1 || perfil > 3) {
                System.out.println("Opção inválida! Tente novamente.");
                continue;
            }

            System.out.print("Digite a senha de acesso: ");
            String senha = scanner.next();

            System.out.println("\n--- RESULTADO DA CONSULTA ---");

            if (perfil == 1 && senha.equals("op123")) {
                System.out.println("Acesso liberado: NÍVEL OPERADOR");
                for (SistemaBancario c : clientes) {
                    System.out.println(c.getDadosOperador());
                }
            } else if (perfil == 2 && senha.equals("ger123")) {
                System.out.println("Acesso liberado: NÍVEL GERÊNCIA");
                for (SistemaBancario c : clientes) {
                    System.out.println(c.getDadosGerencia());
                }
            } else if (perfil == 3 && senha.equals("dir123")) {
                System.out.println("Acesso liberado: NÍVEL DIRETOR");
                for (SistemaBancario c : clientes) {
                    System.out.println(c.getDadosDiretor());
                }
            } else {
                System.out.println("ERRO: Senha incorreta! Voltando ao menu...");
            }
        }

        scanner.close();
    }
}
