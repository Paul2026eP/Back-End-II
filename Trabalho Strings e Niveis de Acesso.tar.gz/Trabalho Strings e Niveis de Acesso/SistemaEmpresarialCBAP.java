import java.util.Scanner;

public class SistemaEmpresarialCBAP {

    // Atributos privados (domínios da Análise de Negócios - CBAP)
    private String area;
    private String operacional; // Execução diária e requisitos funcionais
    private String tatico;      // Métricas, alocação e análise de processos
    private String estrategico; // Visão de futuro, ROI e alinhamento corporativo

    // Construtor
    public SistemaEmpresarialCBAP(String area, String operacional, String tatico, String estrategico) {
        this.area = area;
        this.operacional = operacional;
        this.tatico = tatico;
        this.estrategico = estrategico;
    }

    // Nível 1: OPERADOR (Resumo das operações diárias - usa replace para formatar o rótulo)
    public String getVisaoOperacional() {
        String tag = area.replace(area, "[" + area.toUpperCase() + " - OPERAÇÃO]");
        return tag + " " + operacional;
    }

    // Nível 2: GERÊNCIA (Parte tática - monitoramento de processos e recursos)
    public String getVisaoTatica() {
        return "[" + area.toUpperCase() + " - TÁTICO] " + tatico;
    }

    // Nível 3: DIRETOR (Parte estratégica - governança, valor de negócio e metas globais)
    public String getVisaoEstrategica() {
        return "[" + area.toUpperCase() + " - ESTRATÉGICO] " + estrategico;
    }

    public static void main(String[] args) {
        // --- PARTE 1: Métodos de String aplicados ao contexto CBAP ---
        String frase = "Aprender Java no sistema CBAP";
        System.out.println("Tamanho: " + frase.length());
        System.out.println("Maiúsculo: " + frase.toUpperCase());
        System.out.println("Começa com 'Aprender'? " + frase.startsWith("Aprender"));
        System.out.println("Contém 'Java'? " + frase.contains("Java"));
        System.out.println("Substring (9, 13): " + frase.substring(9, 13));

        // --- PARTE 2: Pilares Empresariais (Tecnológico, Financeiro e Organizacional) ---
        SistemaEmpresarialCBAP[] pilares = {
            new SistemaEmpresarialCBAP(
                "Tecnológico",
                "Monitoramento de chamados, deploy de APIs e manutenção de servidores.",
                "Gestão de backlog técnico, arquitetura de sistemas e SLA de entrega.",
                "Transformação digital, adoção de IA e escalabilidade da infraestrutura."
            ),
            new SistemaEmpresarialCBAP(
                "Financeiro",
                "Conciliação bancária diária, emissão de notas e controle de fluxo de caixa.",
                "Análise de orçamento departamental, redução de custos e margem operacional.",
                "Retorno sobre Investimento (ROI), valuation e captação de novos aportes."
            ),
            new SistemaEmpresarialCBAP(
                "Organizacional",
                "Registro de ponto, atendimento interno de RH e execução de rotinas padrão.",
                "Capacitação de equipes, redesenho de processos (BPM) e avaliação de KPIs.",
                "Governança corporativa, cultura organizacional e expansão de mercado."
            )
        };

        // --- PARTE 3: Loop de Autenticação e Níveis de Decisão ---
        Scanner scanner = new Scanner(System.in);
        int perfil = -1;

        while (perfil != 0) {
            System.out.println("\n=== PORTAL CORPORATIVO (PADRÃO CBAP) ===");
            System.out.println("1 - Operador | 2 - Gerência | 3 - Diretor | 0 - Sair");
            System.out.print("Escolha o nível de acesso: ");
            perfil = scanner.nextInt();

            if (perfil == 0) {
                System.out.println("Encerrando o portal corporativo. Até logo!");
                break;
            }

            if (perfil < 1 || perfil > 3) {
                System.out.println("Opção inválida! Tente novamente.");
                continue;
            }

            System.out.print("Digite a senha de acesso: ");
            String senha = scanner.next();

            System.out.println("\n--- RELATÓRIO EXECUTIVO ---");

            if (perfil == 1 && senha.equals("op123")) {
                System.out.println("Perfil: OPERADOR (Foco: Execução e Requisitos Operacionais)");
                for (SistemaEmpresarialCBAP p : pilares) {
                    System.out.println(p.getVisaoOperacional());
                }
            } else if (perfil == 2 && senha.equals("ger123")) {
                System.out.println("Perfil: GERÊNCIA (Foco: Análise Tática e Otimização de Processos)");
                for (SistemaEmpresarialCBAP p : pilares) {
                    System.out.println(p.getVisaoTatica());
                }
            } else if (perfil == 3 && senha.equals("dir123")) {
                System.out.println("Perfil: DIRETOR (Foco: Estratégia Corporativa e Valor de Negócio)");
                for (SistemaEmpresarialCBAP p : pilares) {
                    System.out.println(p.getVisaoEstrategica());
                }
            } else {
                System.out.println("ERRO: Senha incorreta! Retornando ao menu...");
            }
        }

        scanner.close();
    }
}
